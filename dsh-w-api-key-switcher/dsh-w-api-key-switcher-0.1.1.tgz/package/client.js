window.__ModuleLoader__.load({
  id: "dsh-w-api-key-switcher",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");

    var CSS = [
      ".waks-card{display:flex;flex-direction:column;gap:10px;margin-top:12px;padding:12px;border-top:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-primary)}",
      ".waks-head{display:flex;align-items:center;gap:10px}",
      ".waks-copy{display:flex;min-width:0;flex:1;flex-direction:column;gap:2px}",
      ".waks-title{font-size:13px;line-height:20px;font-weight:600}",
      ".waks-hint,.waks-ref,.waks-note,.waks-status{margin:0;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}",
      ".waks-ref{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--ds-font-family-code)}",
      ".waks-badge{flex:none;max-width:150px;overflow:hidden;padding:2px 8px;border-radius:999px;background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-secondary);font-size:11px;line-height:18px;text-overflow:ellipsis;white-space:nowrap}",
      ".waks-badge[data-active=true]{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);color:var(--dsw-alias-state-business-primary)}",
      ".waks-button{box-sizing:border-box;height:32px;padding:0 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;cursor:pointer}",
      ".waks-button[data-primary=true]{border-color:transparent;background:var(--dsw-alias-state-business-primary);color:#fff;font-weight:600}",
      ".waks-button[data-danger=true]{color:var(--dsw-alias-state-error-primary,#d64545)}",
      ".waks-button:disabled{cursor:default;opacity:.45}",
      ".waks-panel{display:flex;flex-direction:column;gap:12px;padding:12px;border-radius:10px;background:var(--dsw-alias-bg-layer-2)}",
      ".waks-list{display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--dsw-alias-border-l2);border-radius:9px;background:var(--dsw-alias-bg-layer-1)}",
      ".waks-empty{padding:16px;color:var(--dsw-alias-label-tertiary);font-size:12px;text-align:center}",
      ".waks-row{display:flex;align-items:flex-start;gap:12px;padding:11px 12px}",
      ".waks-row+.waks-row{border-top:1px solid var(--dsw-alias-border-l2)}",
      ".waks-row-info{display:flex;min-width:0;flex:1;flex-direction:column;gap:2px}",
      ".waks-row-title{display:flex;align-items:center;gap:7px;min-width:0;font-size:13px;line-height:20px;font-weight:600}",
      ".waks-row-title>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
      ".waks-active{flex:none;padding:1px 6px;border-radius:999px;background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);color:var(--dsw-alias-state-business-primary);font-size:10px;line-height:16px}",
      ".waks-note{white-space:pre-wrap;word-break:break-word}",
      ".waks-actions{display:flex;flex:none;align-items:center;gap:6px;flex-wrap:wrap}",
      ".waks-form{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px}",
      ".waks-field{display:flex;min-width:0;flex-direction:column;gap:5px}",
      ".waks-field[data-wide=true]{grid-column:1/-1}",
      ".waks-label{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;font-weight:600}",
      ".waks-input,.waks-textarea{box-sizing:border-box;width:100%;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;outline:none;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px}",
      ".waks-input{height:34px;padding:0 9px}",
      ".waks-textarea{min-height:68px;padding:8px 9px;resize:vertical;line-height:18px}",
      ".waks-input:focus-visible,.waks-textarea:focus-visible{border-color:var(--dsw-alias-state-business-primary);box-shadow:0 0 0 2px color-mix(in srgb,var(--dsw-alias-state-business-primary) 18%,transparent)}",
      ".waks-input:disabled,.waks-textarea:disabled{opacity:.55}",
      ".waks-status[data-error=true],.waks-warning{margin:0;color:var(--dsw-alias-state-error-primary,#d64545);font-size:12px;line-height:18px}",
      ".waks-status[data-success=true]{color:var(--dsw-alias-state-success-primary,#2f8f5b)}",
      "@media(max-width:720px){.waks-head,.waks-row{align-items:stretch;flex-direction:column}.waks-badge{align-self:flex-start}.waks-actions{align-self:flex-end}.waks-form{grid-template-columns:1fr}.waks-field[data-wide=true]{grid-column:auto}}",
    ].join("\n");

    function installStyle() {
      if (typeof document === "undefined") return null;
      var selector = 'style[data-plugin-css="dsh-w-api-key-switcher/styles"]';
      var node = document.querySelector(selector);
      if (node) return { node: node, owned: false };
      node = document.createElement("style");
      node.dataset.plugin = "dsh-w-api-key-switcher";
      node.dataset.pluginCss = "dsh-w-api-key-switcher/styles";
      node.textContent = CSS;
      document.head.appendChild(node);
      return { node: node, owned: true };
    }

    var passthrough = { parse: function (value) { return value; } };
    function parameter(name) {
      return { name: name, wire: name, source: "json", codec: { mode: "strict", typeSymbol: "json", schema: passthrough } };
    }
    function descriptor(method, parameters) {
      return {
        id: "dsh-w-api-key-switcher#apiKeySwitcher/" + method,
        service: "apiKeySwitcher",
        namespace: "apiKeySwitcher",
        method: method,
        invocation: { kind: "direct" },
        parameters: parameters || [],
        result: { mode: "strict", typeSymbol: "json", schema: passthrough },
      };
    }
    var TYPERT_REMOTE = {
      package: "dsh-w-api-key-switcher",
      descriptors: [
        descriptor("getState", [parameter("provider")]),
        descriptor("saveKey", [parameter("input")]),
        descriptor("switchKey", [parameter("provider"), parameter("id")]),
        descriptor("updateKey", [parameter("input")]),
        descriptor("deleteKey", [parameter("provider"), parameter("id")]),
      ],
    };

    function messageOf(error, fallback) {
      return error && typeof error.message === "string" ? error.message : fallback;
    }

    function ApiKeySwitcherCard(props) {
      var t = props.t;
      var providerId = props.provider.provider;
      var supported = props.provider.settingsNs === "llm-pi-ai" || props.provider.settingsNs === "llm-deepseek";
      var configured = supported && props.configured;
      var expandedSlot = React.useState(false);
      var expanded = expandedSlot[0];
      var setExpanded = expandedSlot[1];
      var stateSlot = React.useState({ status: "loading", value: null, error: null });
      var state = stateSlot[0];
      var setState = stateSlot[1];
      var busySlot = React.useState(false);
      var busy = busySlot[0];
      var setBusy = busySlot[1];
      var feedbackSlot = React.useState(null);
      var feedback = feedbackSlot[0];
      var setFeedback = feedbackSlot[1];
      var formSlot = React.useState({ label: "", note: "", apiKey: "" });
      var form = formSlot[0];
      var setForm = formSlot[1];
      var editSlot = React.useState(null);
      var edit = editSlot[0];
      var setEdit = editSlot[1];
      var mountedRef = React.useRef(false);

      var load = React.useCallback(function () {
        if (!configured) return Promise.resolve();
        return props.getState(providerId).then(function (value) {
          if (!mountedRef.current) return;
          setState({ status: "ready", value: value, error: null });
        }, function (error) {
          if (!mountedRef.current) return;
          setState({ status: "error", value: null, error: messageOf(error, t("loadFailed")) });
        });
      }, [configured, props.getState, providerId, t]);

      React.useEffect(function () {
        mountedRef.current = true;
        void load();
        return function () { mountedRef.current = false; };
      }, [load]);

      React.useEffect(function () {
        return props.subscribe(function () { void load(); });
      }, [props.subscribe, load]);

      if (!configured) return null;
      var value = state.value;
      var entries = value && Array.isArray(value.entries) ? value.entries : [];
      var active = entries.find(function (entry) { return entry.active; });
      var credential = value ? value.credential : null;
      var writable = !credential || credential.writable !== false;
      var badge = state.status === "loading"
        ? t("loading")
        : state.status === "error"
          ? t("loadFailed")
          : active
            ? active.label
            : credential && credential.configured ? t("externalActive") : t("notConfigured");

      function perform(operation, successText) {
        if (busy) return;
        setBusy(true);
        setFeedback(null);
        Promise.resolve().then(operation).then(function (next) {
          if (!mountedRef.current) return;
          setState({ status: "ready", value: next, error: null });
          setFeedback({ error: false, text: successText });
        }, function (error) {
          if (!mountedRef.current) return;
          setFeedback({ error: true, text: messageOf(error, t("operationFailed")) });
        }).finally(function () {
          if (mountedRef.current) setBusy(false);
        });
      }

      function onAdd() {
        if (!form.label.trim() || !form.apiKey.trim()) {
          setFeedback({ error: true, text: t("required") });
          return;
        }
        perform(function () {
          return props.saveKey({ provider: providerId, label: form.label, note: form.note, apiKey: form.apiKey }).then(function (next) {
            if (mountedRef.current) setForm({ label: "", note: "", apiKey: "" });
            return next;
          });
        }, t("savedAndSwitched"));
      }

      function onSwitch(id) {
        perform(function () { return props.switchKey(providerId, id); }, t("switched"));
      }

      function onSaveEdit() {
        if (!edit || !edit.label.trim()) {
          setFeedback({ error: true, text: t("labelRequired") });
          return;
        }
        perform(function () {
          return props.updateKey({ provider: providerId, id: edit.id, label: edit.label, note: edit.note });
        }, t("updated"));
        setEdit(null);
      }

      function onDelete(entry) {
        if (!window.confirm(t("deleteConfirm", { name: entry.label }))) return;
        perform(function () { return props.deleteKey(providerId, entry.id); }, t("deleted"));
      }

      return React.createElement(
        "div",
        { className: "waks-card" },
        React.createElement(
          "div",
          { className: "waks-head" },
          React.createElement(
            "div",
            { className: "waks-copy" },
            React.createElement("span", { className: "waks-title" }, t("title")),
            React.createElement("p", { className: "waks-hint" }, t("hint")),
          ),
          React.createElement("span", { className: "waks-badge", "data-active": !!active || undefined, title: badge }, badge),
          React.createElement(
            "button",
            { type: "button", className: "waks-button", disabled: state.status === "loading", "aria-expanded": expanded, onClick: function () { setExpanded(!expanded); } },
            expanded ? t("collapse") : t("manage"),
          ),
        ),
        state.status === "error"
          ? React.createElement(
              "div",
              { className: "waks-actions" },
              React.createElement("p", { className: "waks-status", "data-error": true }, state.error),
              React.createElement("button", { type: "button", className: "waks-button", onClick: function () { void load(); } }, t("retry")),
            )
          : null,
        expanded && state.status === "ready"
          ? React.createElement(
              "div",
              { className: "waks-panel" },
              React.createElement("p", { className: "waks-ref", title: credential ? credential.ref : "" }, t("credentialRef") + ": " + (credential ? credential.ref : "—")),
              !writable
                ? React.createElement("p", { className: "waks-warning" }, t("readOnly", { source: credential && credential.source ? credential.source : t("unknownSource") }))
                : null,
              React.createElement(
                "div",
                { className: "waks-list" },
                entries.length === 0
                  ? React.createElement("div", { className: "waks-empty" }, t("empty"))
                  : entries.map(function (entry) {
                      var editing = edit && edit.id === entry.id;
                      return React.createElement(
                        "div",
                        { className: "waks-row", key: entry.id },
                        editing
                          ? React.createElement(
                              "div",
                              { className: "waks-form", style: { flex: 1 } },
                              React.createElement(
                                "label", { className: "waks-field" },
                                React.createElement("span", { className: "waks-label" }, t("label")),
                                React.createElement("input", { className: "waks-input", value: edit.label, disabled: busy, maxLength: 80, onChange: function (event) { setEdit(Object.assign({}, edit, { label: event.currentTarget.value })); } }),
                              ),
                              React.createElement(
                                "label", { className: "waks-field" },
                                React.createElement("span", { className: "waks-label" }, t("note")),
                                React.createElement("input", { className: "waks-input", value: edit.note, disabled: busy, maxLength: 500, onChange: function (event) { setEdit(Object.assign({}, edit, { note: event.currentTarget.value })); } }),
                              ),
                              React.createElement(
                                "div", { className: "waks-actions", style: { gridColumn: "1 / -1" } },
                                React.createElement("button", { type: "button", className: "waks-button", "data-primary": true, disabled: busy, onClick: onSaveEdit }, t("saveEdit")),
                                React.createElement("button", { type: "button", className: "waks-button", disabled: busy, onClick: function () { setEdit(null); } }, t("cancel")),
                              ),
                            )
                          : React.createElement(
                              React.Fragment,
                              null,
                              React.createElement(
                                "div",
                                { className: "waks-row-info" },
                                React.createElement(
                                  "div", { className: "waks-row-title" },
                                  React.createElement("span", { title: entry.label }, entry.label),
                                  entry.active ? React.createElement("span", { className: "waks-active" }, t("active")) : null,
                                ),
                                entry.note ? React.createElement("p", { className: "waks-note" }, entry.note) : null,
                              ),
                              React.createElement(
                                "div",
                                { className: "waks-actions" },
                                React.createElement("button", { type: "button", className: "waks-button", "data-primary": !entry.active || undefined, disabled: busy || entry.active || !writable, onClick: function () { onSwitch(entry.id); } }, entry.active ? t("inUse") : t("switch")),
                                React.createElement("button", { type: "button", className: "waks-button", disabled: busy, onClick: function () { setEdit({ id: entry.id, label: entry.label, note: entry.note || "" }); } }, t("edit")),
                                React.createElement("button", { type: "button", className: "waks-button", "data-danger": true, disabled: busy || entry.active, title: entry.active ? t("deleteActiveHint") : "", onClick: function () { onDelete(entry); } }, t("delete")),
                              ),
                            ),
                      );
                    }),
              ),
              React.createElement(
                "div",
                { className: "waks-form" },
                React.createElement(
                  "label", { className: "waks-field" },
                  React.createElement("span", { className: "waks-label" }, t("label")),
                  React.createElement("input", { className: "waks-input", value: form.label, disabled: busy || !writable, maxLength: 80, placeholder: t("labelPlaceholder"), onChange: function (event) { setForm(Object.assign({}, form, { label: event.currentTarget.value })); } }),
                ),
                React.createElement(
                  "label", { className: "waks-field" },
                  React.createElement("span", { className: "waks-label" }, t("apiKey")),
                  React.createElement("input", { className: "waks-input", type: "password", autoComplete: "new-password", value: form.apiKey, disabled: busy || !writable, spellCheck: false, placeholder: "sk-…", onChange: function (event) { setForm(Object.assign({}, form, { apiKey: event.currentTarget.value })); } }),
                ),
                React.createElement(
                  "label", { className: "waks-field", "data-wide": true },
                  React.createElement("span", { className: "waks-label" }, t("note")),
                  React.createElement("textarea", { className: "waks-textarea", value: form.note, disabled: busy || !writable, maxLength: 500, placeholder: t("notePlaceholder"), onChange: function (event) { setForm(Object.assign({}, form, { note: event.currentTarget.value })); } }),
                ),
                React.createElement(
                  "div", { className: "waks-actions", style: { gridColumn: "1 / -1" } },
                  React.createElement("button", { type: "button", className: "waks-button", "data-primary": true, disabled: busy || !writable || !form.label.trim() || !form.apiKey.trim(), onClick: onAdd }, busy ? t("saving") : t("saveAndSwitch")),
                  React.createElement("p", { className: "waks-hint" }, t("secretHint")),
                ),
              ),
              feedback ? React.createElement("p", { className: "waks-status", "data-error": feedback.error || undefined, "data-success": !feedback.error || undefined, role: "status" }, feedback.text) : null,
            )
          : null,
      );
    }

    var NS = "dshWApiKeySwitcher";
    var inject = ["slots", "locale", "remote"];
    var dicts = {
      zh: {
        title: "API 密钥配置",
        hint: "为这个提供商保存多组密钥并一键切换",
        loading: "读取中",
        loadFailed: "读取失败",
        externalActive: "当前密钥未保存",
        notConfigured: "尚未配置",
        manage: "管理",
        collapse: "收起",
        retry: "重试",
        credentialRef: "当前凭据引用",
        readOnly: "当前凭据由 {source} 提供且不可写，请先移除启动环境中的同名变量。",
        unknownSource: "只读来源",
        empty: "还没有保存密钥配置",
        active: "正在使用",
        inUse: "使用中",
        switch: "切换",
        edit: "备注",
        delete: "删除",
        deleteActiveHint: "正在使用的密钥不能删除，请先切换到另一项",
        label: "配置名称",
        labelPlaceholder: "例如：主账号、备用额度、朋友的中转站",
        apiKey: "API Key",
        note: "备注",
        notePlaceholder: "可填写账号、套餐、额度或用途；不要再次粘贴密钥",
        saveAndSwitch: "保存并切换",
        saving: "保存中…",
        secretHint: "密钥只写入 Harness 私密凭据存储，页面不会读取或回显明文。",
        saveEdit: "保存备注",
        cancel: "取消",
        required: "请填写配置名称和 API Key。",
        labelRequired: "配置名称不能为空。",
        savedAndSwitched: "密钥已保存，并已用于下一次模型请求。",
        switched: "已切换；下一次模型请求会使用这组密钥。",
        updated: "名称和备注已更新。",
        deleted: "已删除保存的密钥配置。",
        deleteConfirm: "确定删除“{name}”吗？密钥明文无法恢复。",
        operationFailed: "操作失败。",
      },
      en: {
        title: "API key profiles",
        hint: "Save multiple keys for this provider and switch with one click",
        loading: "Loading",
        loadFailed: "Load failed",
        externalActive: "Current key is not saved",
        notConfigured: "Not configured",
        manage: "Manage",
        collapse: "Collapse",
        retry: "Retry",
        credentialRef: "Credential reference",
        readOnly: "This credential is supplied by {source} and is read-only. Remove the same variable from the launch environment first.",
        unknownSource: "a read-only source",
        empty: "No saved key profiles yet",
        active: "Active",
        inUse: "In use",
        switch: "Switch",
        edit: "Edit note",
        delete: "Delete",
        deleteActiveHint: "Switch to another saved key before deleting the active one",
        label: "Profile name",
        labelPlaceholder: "For example: primary, backup quota, or relay account",
        apiKey: "API key",
        note: "Note",
        notePlaceholder: "Account, plan, quota, or purpose. Do not paste the key again.",
        saveAndSwitch: "Save and switch",
        saving: "Saving…",
        secretHint: "Keys are written only to Harness's private credential store and are never read back into the page.",
        saveEdit: "Save note",
        cancel: "Cancel",
        required: "Enter a profile name and API key.",
        labelRequired: "Profile name is required.",
        savedAndSwitched: "The key was saved and will be used by the next model request.",
        switched: "Switched. The next model request will use this key.",
        updated: "Name and note updated.",
        deleted: "Saved key profile deleted.",
        deleteConfirm: "Delete “{name}”? The secret cannot be recovered.",
        operationFailed: "Operation failed.",
      },
    };

    async function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style && style.owned) style.node.remove(); }; }, "dsh-w-api-key-switcher: styles");
      ctx.effect(function () { return ctx.locale.register(NS, dicts); });
      var unmount = await ctx.remote.$mount(TYPERT_REMOTE);
      ctx.effect(function () { return unmount; }, "dsh-w-api-key-switcher: remote");
      var service = ctx.get("remote.apiKeySwitcher");
      if (!service) throw new Error("dsh-w-api-key-switcher: remote.apiKeySwitcher did not mount");
      var listeners = new Set();
      ctx.effect(function () {
        return ctx.remote.$on("credentials/reference-updated", function () {
          listeners.forEach(function (listener) { listener(); });
        });
      }, "dsh-w-api-key-switcher: credential refresh");

      async function unwrap(method, args) {
        var answer = await service[method].apply(service, args);
        if (!answer.ok) throw new Error(answer.error && answer.error.message ? answer.error.message : JSON.stringify(answer.error));
        return answer.value;
      }
      function subscribe(listener) {
        listeners.add(listener);
        return function () { listeners.delete(listener); };
      }
      var t = ctx.locale.bind(NS);
      function injected() {
        return {
          t: t,
          subscribe: subscribe,
          getState: function (provider) { return unwrap("getState", [provider]); },
          saveKey: function (input) { return unwrap("saveKey", [input]); },
          switchKey: function (provider, id) { return unwrap("switchKey", [provider, id]); },
          updateKey: function (input) { return unwrap("updateKey", [input]); },
          deleteKey: function (provider, id) { return unwrap("deleteKey", [provider, id]); },
        };
      }
      ["llm-pi-ai", "llm-deepseek"].forEach(function (settingsNs) {
        ctx.slots.inject("settings.models.provider-card", function () {
          return ctx.slots.register({
            name: "settings.models.provider-card",
            key: settingsNs,
            inject: injected,
          }, ApiKeySwitcherCard);
        });
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.name = "dsh-w-api-key-switcher";
    return module.exports;
  },
});
