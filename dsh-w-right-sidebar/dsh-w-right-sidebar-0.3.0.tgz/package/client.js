window.__ModuleLoader__.load({
  id: "dsh-w-right-sidebar",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");

    var CSS = [
      ".dshwrs-root{position:fixed;top:0;right:0;bottom:0;z-index:2147482990;display:flex;flex-direction:row;pointer-events:none;color:var(--dsw-alias-label-primary,#1f2329);font-family:var(--dsw-font-ui,ui-sans-serif,system-ui,sans-serif)}",
      ".dshwrs-page{width:356px;min-width:0;height:100%;display:flex;flex-direction:column;overflow:hidden;background:var(--dsw-alias-bg-layer-1,#fff);border-left:1px solid var(--dsw-alias-border-l2,#d7dbe2);box-shadow:-8px 0 28px rgba(0,0,0,.12);pointer-events:auto}",
      ".dshwrs-page-header{height:60px;flex:none;display:flex;align-items:center;gap:10px;padding:0 12px;border-bottom:1px solid var(--dsw-alias-border-l1,#e6e9ee);font-size:16px;font-weight:600}",
      ".dshwrs-page-title{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
      ".dshwrs-page-body{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column}",
      ".dshwrs-tool-list{flex:1;min-height:0;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:10px}",
      ".dshwrs-tool-card{width:100%;display:flex;align-items:center;gap:12px;padding:12px;border:1px solid var(--dsw-alias-border-l1,#e6e9ee);border-radius:12px;background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-primary,#1f2329);text-align:left;cursor:pointer;box-shadow:0 1px 2px rgba(31,35,41,.04)}",
      ".dshwrs-tool-card:hover{border-color:var(--dsw-alias-state-business-primary,#3978e8);background:var(--dsw-alias-interactive-bg-hover,#f5f8ff)}",
      ".dshwrs-tool-card-icon{width:38px;height:38px;flex:none;display:flex;align-items:center;justify-content:center;border-radius:10px;background:var(--dsw-specific-sidebar-fill,#f7f8fa);font-size:22px;line-height:1}",
      ".dshwrs-tool-card-copy{min-width:0;display:flex;flex-direction:column;gap:3px}",
      ".dshwrs-tool-card-title{font-size:14px;font-weight:600;line-height:20px}",
      ".dshwrs-tool-card-description{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary,#68717e)}",
      ".dshwrs-rail{width:56px;height:100%;display:flex;flex-direction:column;align-items:center;gap:10px;padding:18px 10px 10px;box-sizing:border-box;background:var(--dsw-specific-sidebar-fill,#f7f8fa);border-left:1px solid var(--dsw-alias-border-l1,#e6e9ee);pointer-events:auto}",
      ".dshwrs-button{width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:0;background:transparent;color:var(--dsw-alias-label-secondary,#68717e);cursor:pointer}",
      ".dshwrs-button:hover{background:var(--dsw-alias-interactive-bg-hover,#e9edf3);color:var(--dsw-alias-label-primary,#1f2329)}",
      ".dshwrs-button[data-active=true]{background:var(--dsw-alias-interactive-bg-selected,#dce8ff);color:var(--dsw-alias-state-business-primary,#3978e8)}",
      ".dshwrs-toggle{margin-bottom:6px;border-radius:50%}",
      ".dshwrs-feature{width:36px;height:36px;display:flex;align-items:center;justify-content:center}",
      ".dshwrs-empty{padding:28px;color:var(--dsw-alias-label-tertiary,#87909d);font-size:13px;line-height:20px}",
      "@media (max-width:720px){.dshwrs-page{width:min(356px,calc(100vw - 56px))}}",
    ].join("\n");
    var tagId = "dsh-w-right-sidebar/styles";

    function installStyle() {
      if (typeof document === "undefined") return { owned: false, node: null };
      var existing = document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]");
      if (existing) return { owned: false, node: existing };
      var node = document.createElement("style");
      node.dataset.plugin = "dsh-w-right-sidebar";
      node.dataset.pluginCss = tagId;
      node.textContent = CSS;
      document.head.appendChild(node);
      return { owned: true, node: node };
    }

    function IconSidebar() {
      return React.createElement("svg", { viewBox: "0 0 20 20", width: 18, height: 18, "aria-hidden": true },
        React.createElement("rect", { x: 3, y: 3, width: 14, height: 14, rx: 2, fill: "none", stroke: "currentColor", strokeWidth: 1.5 }),
        React.createElement("path", { d: "M8 3v14", stroke: "currentColor", strokeWidth: 1.5 })
      );
    }

    function IconBack() {
      return React.createElement("svg", { viewBox: "0 0 20 20", width: 16, height: 16, "aria-hidden": true },
        React.createElement("path", { d: "M11.5 4.5L6 10l5.5 5.5M6.5 10H15", fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round" })
      );
    }

    function RightSidebarHost(props) {
      var t = typeof props.t === "function" ? props.t : function (key) { return key; };
      var openSlot = React.useState(false);
      var open = openSlot[0];
      var setOpen = openSlot[1];
      var activeSlot = React.useState(null);
      var activeId = activeSlot[0];
      var setActiveId = activeSlot[1];
      var modeSlot = React.useState("list");
      var mode = modeSlot[0];
      var setMode = modeSlot[1];
      var originSlot = React.useState("direct");
      var origin = originSlot[0];
      var setOrigin = originSlot[1];
      var showList = function () {
        setOpen(true);
        setMode("list");
        setActiveId(null);
      };
      var collapse = function () {
        setOpen(false);
        setMode("list");
        setActiveId(null);
      };
      var openFromCard = function (id) {
        setActiveId(id);
        setOrigin("list");
        setMode("page");
        setOpen(true);
      };
      var openDirect = function (id) {
        setActiveId(id);
        setOrigin("direct");
        setMode("page");
        setOpen(true);
      };
      var body = mode === "list"
        ? React.createElement("div", { className: "dshwrs-tool-list" },
          props.renderSlot("right-sidebar.card", { onOpen: openFromCard }, {
            fallback: React.createElement("div", { className: "dshwrs-empty" }, t("empty")),
          })
        )
        : React.createElement("div", { className: "dshwrs-page-body" },
          props.renderSlotChain("right-sidebar.page", { activeId: activeId }, {
            fallback: React.createElement("div", { className: "dshwrs-empty" }, t("empty")),
          })
        );
      var rail = props.renderSlot("right-sidebar.rail", {
        activeId: activeId,
        onSelect: function (id) {
          openDirect(id);
        },
      });
      var headerBack = mode === "page" && origin === "list";
      return React.createElement("div", { className: "dshwrs-root", "data-open": open || undefined },
        open ? React.createElement("section", { className: "dshwrs-page", "aria-label": t("title") },
          React.createElement("header", { className: "dshwrs-page-header" },
            React.createElement("button", {
              type: "button",
              className: "dshwrs-button",
              title: headerBack ? t("back") : t("collapse"),
              "aria-label": headerBack ? t("back") : t("collapse"),
              onClick: headerBack ? showList : collapse,
            }, headerBack ? React.createElement(IconBack, null) : React.createElement(IconSidebar, null)),
            React.createElement("span", { className: "dshwrs-page-title" }, t("title")),
          ),
          body
        ) : null,
        React.createElement("aside", { className: "dshwrs-rail", "aria-label": t("rail") },
          React.createElement("button", {
            type: "button",
            className: "dshwrs-button dshwrs-toggle",
            title: open ? t("collapse") : t("expand"),
            "aria-label": open ? t("collapse") : t("expand"),
            onClick: open ? collapse : showList,
          }, React.createElement(IconSidebar, null)),
          rail
        )
      );
    }

    var NS = "dshWRightSidebar";
    var inject = ["slots", "locale"];
    var dicts = {
      zh: { title: "右侧工具", rail: "右侧工具栏", collapse: "收起右侧栏", expand: "展开右侧栏", back: "返回工具列表", empty: "右侧栏暂无已挂载工具。" },
      en: { title: "Right tools", rail: "Right tools", collapse: "Collapse right sidebar", expand: "Expand right sidebar", back: "Back to tools", empty: "No right-sidebar tools are mounted." },
    };

    function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style.owned && style.node) style.node.remove(); }; }, "dsh-w-right-sidebar: styles");
      ctx.effect(function () { return ctx.locale.register(NS, dicts); });
      ctx.slots.inject("shell.overlay", function () {
        return ctx.slots.register({
          name: "shell.overlay",
          id: "right-sidebar",
          order: 80,
          locale: NS,
          children: {
            "right-sidebar.rail": { kind: "list", scope: "root" },
            "right-sidebar.card": { kind: "list", scope: "root" },
            "right-sidebar.page": { kind: "chain", scope: "root" },
          },
        }, RightSidebarHost);
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.name = "dsh-w-right-sidebar";
    return module.exports;
  },
});
