# dsh-w-right-sidebar

`dsh-w-right-sidebar` 是 W 系列插件共用的右侧 Sidebar 宿主（当前版本 `0.2.0`）：

- 展开时占据右侧整列，内部承载功能页面。
- 收缩时保留一条右侧竖栏。
- 竖栏中的每个图标/入口由其他 W 插件注册。
- 当前 `dsh-w-whale-tail` 会作为第一个功能页挂载到这里。
- 展开状态下，功能页面位于左侧，入口竖栏固定在最右侧；收缩后只保留最右侧竖栏。

这个插件本身不提供业务功能，也不替换 Harness 左侧导航栏或官方工具详情逻辑。

## 安装

```powershell
pnpm pack
dsh plugin --profile web add ./dsh-w-right-sidebar-0.2.0.tgz
```

建议先安装本插件，再安装依赖它的右侧功能插件。

## 卸载

```powershell
dsh plugin --profile web remove dsh-w-right-sidebar
```
