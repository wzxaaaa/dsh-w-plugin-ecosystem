window.__ModuleLoader__.load({
  id: "dsh-w-right-sidebar",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");

    var CSS = [
      ".dshwrs-root{position:fixed;top:0;right:0;bottom:0;z-index:2147482990;display:flex;flex-direction:row;pointer-events:none;color:var(--dsw-alias-label-primary,#1f2329);font-family:var(--dsw-font-ui,ui-sans-serif,system-ui,sans-serif)}",
      ".dshwrs-page{width:356px;min-width:0;height:100%;display:flex;flex-direction:column;overflow:hidden;background:var(--dsw-alias-bg-layer-1,#fff);border-left:1px solid var(--dsw-alias-border-l2,#d7dbe2);box-shadow:-8px 0 28px rgba(0,0,0,.12);pointer-events:auto}",
      ".dshwrs-page-header{height:60px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 12px 0 18px;border-bottom:1px solid var(--dsw-alias-border-l1,#e6e9ee);font-size:16px;font-weight:600}",
      ".dshwrs-page-title{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
      ".dshwrs-page-body{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column}",
      ".dshwrs-rail{width:56px;height:100%;display:flex;flex-direction:column;align-items:center;gap:10px;padding:18px 10px 10px;box-sizing:border-box;background:var(--dsw-specific-sidebar-fill,#f7f8fa);border-left:1px solid var(--dsw-alias-border-l1,#e6e9ee);pointer-events:auto}",
      ".dshwrs-button{width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:0;background:transparent;color:var(--dsw-alias-label-secondary,#68717e);cursor:pointer}",
      ".dshwrs-button:hover{background:var(--dsw-alias-interactive-bg-hover,#e9edf3);color:var(--dsw-alias-label-primary,#1f2329)}",
      ".dshwrs-button[data-active=true]{background:var(--dsw-alias-interactive-bg-selected,#dce8ff);color:var(--dsw-alias-state-business-primary,#3978e8)}",
      ".dshwrs-toggle{margin-bottom:6px;border-radius:50%}",
      ".dshwrs-feature{width:36px;height:36px;display:flex;align-items:center;justify-content:center}",
      ".dshwrs-empty{padding:28px;color:var(--dsw-alias-label-tertiary,#87909d);font-size:13px;line-height:20px}",
      "@media (max-width:720px){.dshwrs-page{width:min(356px,calc(100vw - 56px))}}",
    ].join("\n");
    var tagId = "dsh-w-right-sidebar/styles";

    function installStyle() {
      if (typeof document === "undefined") return { owned: false, node: null };
      var existing = document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]");
      if (existing) return { owned: false, node: existing };
      var node = document.createElement("style");
      node.dataset.plugin = "dsh-w-right-sidebar";
      node.dataset.pluginCss = tagId;
      node.textContent = CSS;
      document.head.appendChild(node);
      return { owned: true, node: node };
    }

    function IconPanel() {
      return React.createElement("svg", { viewBox: "0 0 20 20", width: 18, height: 18, "aria-hidden": true },
        React.createElement("path", { d: "M3 4.5h14M3 10h14M3 15.5h14", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" })
      );
    }

    function IconClose() {
      return React.createElement("svg", { viewBox: "0 0 20 20", width: 16, height: 16, "aria-hidden": true },
        React.createElement("path", { d: "M5 5l10 10M15 5L5 15", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" })
      );
    }

    function RightSidebarHost(props) {
      var t = typeof props.t === "function" ? props.t : function (key) { return key; };
      var openSlot = React.useState(true);
      var open = openSlot[0];
      var setOpen = openSlot[1];
      var activeSlot = React.useState("whale-tail");
      var activeId = activeSlot[0];
      var setActiveId = activeSlot[1];
      var page = props.renderSlotChain("right-sidebar.page", { activeId: activeId }, {
        fallback: React.createElement("div", { className: "dshwrs-empty" }, t("empty")),
      });
      var rail = props.renderSlot("right-sidebar.rail", {
        activeId: activeId,
        onSelect: function (id) {
          setActiveId(id);
          setOpen(true);
        },
      });
      return React.createElement("div", { className: "dshwrs-root", "data-open": open || undefined },
        open ? React.createElement("section", { className: "dshwrs-page", "aria-label": t("title") },
          React.createElement("header", { className: "dshwrs-page-header" },
            React.createElement("span", { className: "dshwrs-page-title" }, t("title")),
            React.createElement("button", {
              type: "button",
              className: "dshwrs-button",
              title: t("collapse"),
              "aria-label": t("collapse"),
              onClick: function () { setOpen(false); },
            }, React.createElement(IconClose, null))
          ),
          React.createElement("div", { className: "dshwrs-page-body" }, page)
        ) : null,
        React.createElement("aside", { className: "dshwrs-rail", "aria-label": t("rail") },
          React.createElement("button", {
            type: "button",
            className: "dshwrs-button dshwrs-toggle",
            title: open ? t("collapse") : t("expand"),
            "aria-label": open ? t("collapse") : t("expand"),
            onClick: function () { setOpen(!open); },
          }, React.createElement(IconPanel, null)),
          rail
        )
      );
    }

    var NS = "dshWRightSidebar";
    var inject = ["slots", "locale"];
    var dicts = {
      zh: { title: "右侧工具", rail: "右侧工具栏", collapse: "收起右侧栏", expand: "展开右侧栏", empty: "右侧栏暂无打开的功能。" },
      en: { title: "Right tools", rail: "Right tools", collapse: "Collapse right sidebar", expand: "Expand right sidebar", empty: "No right-sidebar feature is open." },
    };

    function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style.owned && style.node) style.node.remove(); }; }, "dsh-w-right-sidebar: styles");
      ctx.effect(function () { return ctx.locale.register(NS, dicts); });
      ctx.slots.inject("shell.overlay", function () {
        return ctx.slots.register({
          name: "shell.overlay",
          id: "right-sidebar",
          order: 80,
          locale: NS,
          children: {
            "right-sidebar.rail": { kind: "list", scope: "root" },
            "right-sidebar.page": { kind: "chain", scope: "root" },
          },
        }, RightSidebarHost);
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.name = "dsh-w-right-sidebar";
    return module.exports;
  },
});
