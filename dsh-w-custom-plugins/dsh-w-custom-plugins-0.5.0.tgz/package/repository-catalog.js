import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { compareSemver } from './custom-plugin-core.js'

export const REPOSITORY = 'wzxaaaa/dsh-w-plugin-ecosystem'
const API = `https://api.github.com/repos/${REPOSITORY}`
const TTL = 10 * 60 * 1000
const SHA = /^[a-f0-9]{40}$/u
const NAME = /^dsh-w-[a-z0-9][a-z0-9-]*$/u

export function validCatalogEntry(entry) {
  return NAME.test(entry?.moduleName ?? '') && compareSemver(entry.version, entry.version) === 0
    && typeof entry.description === 'string' && entry.description.length <= 5000
    && SHA.test(entry.ref ?? '') && (entry.archiveSha === null || SHA.test(entry.archiveSha ?? ''))
}

async function githubJson(path, maxBytes = 2 * 1024 * 1024) {
  const response = await fetch(`${API}/${path}`, {
    headers: { accept: 'application/vnd.github+json', 'user-agent': 'dsh-w-custom-plugins' },
    redirect: 'error', signal: AbortSignal.timeout(20_000),
  })
  if (!response.ok) throw new Error(`GitHub HTTP ${response.status}${response.status === 403 || response.status === 429 ? ' (API rate limit)' : ''}`)
  const chunks = []
  let size = 0
  for await (const chunk of response.body) {
    size += chunk.length
    if (size > maxBytes) throw new Error('GitHub response exceeds the size limit')
    chunks.push(chunk)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

function decodeBlob(blob, maxBytes) {
  if (blob.encoding !== 'base64' || typeof blob.content !== 'string') throw new Error('GitHub blob encoding is invalid')
  const bytes = Buffer.from(blob.content, 'base64')
  if (bytes.length === 0 || bytes.length > maxBytes) throw new Error('GitHub blob exceeds the size limit')
  return bytes
}

/** Discover package manifests and version-matched archives from one immutable commit. */
export async function fetchRepositoryCatalog(previous = []) {
  const tree = await githubJson('git/trees/main?recursive=1', 8 * 1024 * 1024)
  if (!SHA.test(tree.sha ?? '') || tree.truncated || !Array.isArray(tree.tree)) throw new Error('GitHub returned an incomplete repository tree')
  const files = new Map(tree.tree.filter(item => item.type === 'blob').map(item => [item.path, item]))
  const manifests = [...files.values()].filter(item => /^dsh-w-[a-z0-9-]+\/package.json$/u.test(item.path))
  if (manifests.length > 200) throw new Error('Repository contains too many plugins')
  if (previous.length === manifests.length && previous.every(validCatalogEntry)
    && previous.every(entry => entry.ref === tree.sha && files.has(`${entry.moduleName}/package.json`))) return previous
  const entries = []
  // Bound API concurrency; a complete snapshot is cached rather than listing a partial success.
  let cursor = 0
  await Promise.all(Array.from({ length: Math.min(4, manifests.length) }, async () => {
    while (cursor < manifests.length) {
      const item = manifests[cursor++]
      if (!SHA.test(item.sha)) throw new Error('GitHub returned an invalid manifest blob')
      const manifest = JSON.parse(decodeBlob(await githubJson(`git/blobs/${item.sha}`), 1024 * 1024).toString('utf8'))
      const moduleName = item.path.split('/')[0]
      if (manifest.name !== moduleName || typeof manifest.dsh?.bundle?.patch !== 'string') continue
      const archive = files.get(`${moduleName}/${moduleName}-${manifest.version}.tgz`)
      const entry = { moduleName, version: manifest.version, description: typeof manifest.description === 'string' ? manifest.description.slice(0, 5000) : '', ref: tree.sha, archiveSha: archive?.sha ?? null }
      if (!validCatalogEntry(entry)) throw new Error(`Invalid repository manifest: ${moduleName}`)
      entries.push(entry)
    }
  }))
  return entries.sort((a, b) => a.moduleName.localeCompare(b.moduleName))
}

export async function readCatalogCache(path) {
  try {
    const stat = await readFile(path, 'utf8')
    if (Buffer.byteLength(stat) > 2 * 1024 * 1024) return undefined
    const cache = JSON.parse(stat)
    if (!Number.isFinite(cache.time) || !Array.isArray(cache.entries) || !cache.entries.every(validCatalogEntry)) return undefined
    return cache
  } catch { return undefined }
}

export class RepositoryCatalog {
  constructor(cachePath, fetcher = fetchRepositoryCatalog) { this.cachePath = cachePath; this.fetcher = fetcher }
  async snapshot(force = false) {
    if (!this.cache) this.cache = await readCatalogCache(this.cachePath)
    if (!force && this.lastFailure && Date.now() - this.lastFailure.time < 30_000) return this.lastFailure.snapshot
    if (!force && this.cache && Date.now() - this.cache.time < TTL) return { entries: this.cache.entries, warning: '' }
    if (!this.pending) this.pending = (async () => {
      try {
        const entries = await this.fetcher(this.cache?.entries ?? [])
        this.cache = { time: Date.now(), entries }
        this.lastFailure = undefined
        await writeFile(this.cachePath, JSON.stringify(this.cache)).catch(() => {})
        return { entries, warning: '' }
      } catch (error) {
        const snapshot = { entries: this.cache?.entries ?? [], warning: String(error.message || error), stale: true }
        this.lastFailure = { time: Date.now(), snapshot }
        return snapshot
      } finally { this.pending = undefined }
    })()
    return this.pending
  }
}

/** Download a pinned blob. Git's blob digest detects wrong or corrupted archives. */
export async function downloadRepositoryArchive(entry, destination) {
  if (!validCatalogEntry(entry) || entry.archiveSha === null) throw new Error('Repository has not published an archive for this plugin version')
  const bytes = decodeBlob(await githubJson(`git/blobs/${entry.archiveSha}`, 172 * 1024 * 1024), 128 * 1024 * 1024)
  const digest = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex')
  if (digest !== entry.archiveSha) throw new Error('Repository archive digest does not match')
  await writeFile(destination, bytes, { flag: 'wx' })
}

export function mergeCatalog(installed, catalog) {
  const names = new Set(installed.map(entry => entry.moduleName))
  const byName = new Map(catalog.map(entry => [entry.moduleName, entry]))
  return [
    ...installed.map(entry => ({ ...entry, installed: true, latestVersion: byName.get(entry.moduleName)?.version ?? '', description: byName.get(entry.moduleName)?.description ?? '' })),
    ...catalog.filter(entry => !names.has(entry.moduleName)).map(entry => ({ entryId: `repository:${entry.moduleName}`, moduleName: entry.moduleName, version: entry.version, description: entry.description, installed: false, enabled: false, downloadable: entry.archiveSha !== null })),
  ]
}
