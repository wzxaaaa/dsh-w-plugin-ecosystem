/**
 * dsh-w-custom-plugins — Host half.
 *
 * Exposes a Typert Remote service `customPlugins`:
 *   - listCustom(): current non-builtin loader entries with their PERSISTED
 *     enabled state (read from the profile patch, so the switch reflects the
 *     saved intent immediately).
 *   - setEnabled(entryId, enabled): persist an enable/disable patch entry into
 *     the active profile's cordis.patch.yml AND apply it at runtime right away
 *     (entry.update({ disabled })), so no restart is required.
 *
 * NOTE: decorators are emitted in the tsdown-compiled form (__esDecorate +
 * __runInitializers) because the shipped Node runtime does not enable the
 * native stage-3 decorator syntax by default.
 */

import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { appendFile, copyFile, lstat, mkdir, mkdtemp, open, readFile, readdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as yaml from 'js-yaml'
import { compareSemver, isCustomModule } from './custom-plugin-core.js'
import { RepositoryCatalog, downloadRepositoryArchive, mergeCatalog } from './repository-catalog.js'
import { installWithHarness } from './harness-install.js'

var __runInitializers = function (thisArg, initializers, value) {
  var useValue = arguments.length > 2
  for (var i = 0; i < initializers.length; i++) value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg)
  return useValue ? value : void 0
}
var __esDecorate = function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
  function accept(f) {
    if (f !== void 0 && typeof f !== 'function') throw new TypeError('Function expected')
    return f
  }
  var kind = contextIn.kind, key = kind === 'getter' ? 'get' : kind === 'setter' ? 'set' : 'value'
  var target = !descriptorIn && ctor ? contextIn['static'] ? ctor : ctor.prototype : null
  var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {})
  var _, done = false
  for (var i = decorators.length - 1; i >= 0; i--) {
    var context = {}
    for (var p in contextIn) context[p] = p === 'access' ? {} : contextIn[p]
    for (var p in contextIn.access) context.access[p] = contextIn.access[p]
    context.addInitializer = function (f) {
      if (done) throw new TypeError('Cannot add initializers after decoration has completed')
      extraInitializers.push(accept(f || null))
    }
    var result = (0, decorators[i])(kind === 'accessor' ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context)
    if (kind === 'accessor') {
      if (result === void 0) continue
      if (result === null || typeof result !== 'object') throw new TypeError('Object expected')
      if (_ = accept(result.get)) descriptor.get = _
      if (_ = accept(result.set)) descriptor.set = _
      if (_ = accept(result.init)) initializers.unshift(_)
    } else if (_ = accept(result)) if (kind === 'field') initializers.unshift(_)
    else descriptor[key] = _
  }
  if (target) Object.defineProperty(target, contextIn.name, descriptor)
  done = true
}

const PATCH_FILE = 'cordis.patch.yml'
const MANAGER_PACKAGE = 'dsh-w-custom-plugins'
const PATCH_LOCK_SUFFIX = '.dsh-w.lock'
const PATCH_LOCK_STALE_MS = 30_000
const PATCH_LOCK_TIMEOUT_MS = 10_000

function sleep(ms) {
  return new Promise(resolvePromise => setTimeout(resolvePromise, ms))
}

async function readPatchArray(path) {
  let raw
  try {
    raw = await readFile(path, 'utf8')
  } catch (error) {
    if (error && error.code === 'ENOENT') return []
    throw error
  }
  if (raw.trim() === '') return []
  const parsed = yaml.load(raw)
  if (parsed == null) return []
  if (!Array.isArray(parsed)) {
    throw new Error('cordis.patch.yml must contain a YAML list; refusing to overwrite it')
  }
  return parsed
}

async function withPatchLock(path, callback) {
  const lockPath = path + PATCH_LOCK_SUFFIX
  const deadline = Date.now() + PATCH_LOCK_TIMEOUT_MS
  let handle
  while (handle === undefined) {
    try {
      const candidate = await open(lockPath, 'wx')
      try {
        await candidate.writeFile(JSON.stringify({ pid: process.pid, createdAt: Date.now() }), 'utf8')
        handle = candidate
      } catch (error) {
        await candidate.close().catch(() => {})
        await rm(lockPath, { force: true }).catch(() => {})
        throw error
      }
    } catch (error) {
      if (!error || error.code !== 'EEXIST') throw error
      try {
        const info = await stat(lockPath)
        if (Date.now() - info.mtimeMs > PATCH_LOCK_STALE_MS) {
          await rm(lockPath, { force: true })
          continue
        }
      } catch (statError) {
        if (!statError || statError.code !== 'ENOENT') throw statError
        continue
      }
      if (Date.now() >= deadline) throw new Error('Timed out waiting to update cordis.patch.yml')
      await sleep(40)
    }
  }
  try {
    return await callback()
  } finally {
    await handle.close().catch(() => {})
    await rm(lockPath, { force: true }).catch(() => {})
  }
}

async function writePatchArrayAtomic(path, data) {
  const tempPath = join(dirname(path), '.' + basename(path) + '.' + process.pid + '.' + randomUUID() + '.tmp')
  try {
    await writeFile(tempPath, yaml.dump(data, { noRefs: true, lineWidth: 120 }), 'utf8')
    await rename(tempPath, path)
  } finally {
    await rm(tempPath, { force: true }).catch(() => {})
  }
}

async function mutatePatchArray(path, callback) {
  return withPatchLock(path, async () => {
    const current = await readPatchArray(path)
    const next = await callback(current)
    if (!Array.isArray(next)) throw new Error('patch mutation must return an array')
    await writePatchArrayAtomic(path, next)
    return next
  })
}

/** Map an expanded Loader child id back to the profile-composition row id. */
function profileEntryId(entryId) {
  const includePrefix = 'include:'
  return entryId.startsWith(includePrefix) ? entryId.slice(includePrefix.length) : entryId
}

function updateDisabledPatch(data, persistedId, entryId, enabled) {
  const next = []
  for (const patch of data) {
    if (!patch || patch.disabled !== true || (patch.id !== persistedId && patch.id !== entryId)) {
      next.push(patch)
      continue
    }
    const preserved = { ...patch }
    delete preserved.disabled
    if (Object.keys(preserved).some(key => key !== 'id')) next.push(preserved)
  }
  if (!enabled) next.push({ id: persistedId, disabled: true })
  return next
}


const MAX_UPLOAD_BYTES = 128 * 1024 * 1024
const MAX_CHUNK_BYTES = 512 * 1024
const MAX_BASE64_CHARS = Math.ceil(MAX_CHUNK_BYTES / 3) * 4
const MAX_EXTRACTED_BYTES = 512 * 1024 * 1024
const MAX_EXTRACTED_FILES = 10_000
const MAX_PACKAGE_JSON_BYTES = 1024 * 1024
const MAX_COMMAND_OUTPUT_BYTES = 8 * 1024 * 1024
const COMMAND_TIMEOUT_MS = 5 * 60 * 1000
const UPLOAD_TTL_MS = 30 * 60 * 1000
const UPLOAD_SWEEP_MS = 5 * 60 * 1000
const MANIFEST_TIMEOUT_MS = 30 * 1000
const DOWNLOAD_TIMEOUT_MS = 5 * 60 * 1000
const MAX_REMOTE_MANIFEST_BYTES = 1024 * 1024

function assertTrustedHttpsUrl(value, hosts) {
  let url
  try { url = new URL(value) } catch { throw new Error('Update source returned an invalid URL') }
  if (url.protocol !== 'https:' || !hosts.has(url.hostname)) {
    throw new Error(`Update source returned an untrusted URL: ${url.origin}`)
  }
  return url.href
}

function isTransientRemoteError(error) {
  const code = error?.cause?.code ?? error?.code
  if (['ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EAI_AGAIN', 'ENETUNREACH'].includes(code)) return true
  const message = error instanceof Error ? error.message : String(error)
  if (/timed out|fetch failed/iu.test(message)) return true
  const status = /HTTP (\d{3})/u.exec(message)
  return status !== null && (status[1] === '429' || Number(status[1]) >= 500)
}

async function retryRemote(operation) {
  let failure
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try { return await operation() } catch (error) {
      failure = error
      if (!isTransientRemoteError(error) || attempt === 2) throw error
      await sleep(250 * (attempt + 1))
    }
  }
  throw failure
}

async function fetchRemoteJson(url, hosts, missingOk = false) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), MANIFEST_TIMEOUT_MS)
  try {
    const response = await fetch(assertTrustedHttpsUrl(url, hosts), {
      headers: { accept: 'application/json' },
      redirect: 'error',
      signal: controller.signal,
    })
    if (missingOk && response.status === 404) return undefined
    if (!response.ok) throw new Error(`Update server returned HTTP ${String(response.status)}`)
    assertTrustedHttpsUrl(response.url, hosts)
    const declared = Number(response.headers.get('content-length'))
    if (Number.isFinite(declared) && declared > MAX_REMOTE_MANIFEST_BYTES) {
      throw new Error('Update manifest exceeds the 1 MB safety limit')
    }
    const bytes = Buffer.from(await response.arrayBuffer())
    if (bytes.length > MAX_REMOTE_MANIFEST_BYTES) throw new Error('Update manifest exceeds the 1 MB safety limit')
    try { return JSON.parse(bytes.toString('utf8')) } catch { throw new Error('Update server returned invalid JSON') }
  } catch (error) {
    if (controller.signal.aborted) throw new Error('Update request timed out')
    throw error
  } finally {
    clearTimeout(timer)
  }
}

async function downloadRemoteArchive(url, destination, hosts) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), DOWNLOAD_TIMEOUT_MS)
  let handle
  try {
    const response = await fetch(assertTrustedHttpsUrl(url, hosts), {
      headers: { accept: 'application/octet-stream' },
      redirect: 'error',
      signal: controller.signal,
    })
    if (!response.ok) throw new Error(`Update server returned HTTP ${String(response.status)}`)
    assertTrustedHttpsUrl(response.url, hosts)
    const declared = Number(response.headers.get('content-length'))
    if (Number.isFinite(declared) && declared > MAX_UPLOAD_BYTES) {
      throw new Error('Online plugin archive exceeds the 128 MB safety limit')
    }
    if (response.body === null) throw new Error('Update server returned an empty response')
    handle = await open(destination, 'wx')
    let received = 0
    for await (const chunk of response.body) {
      const bytes = Buffer.from(chunk)
      received += bytes.length
      if (received > MAX_UPLOAD_BYTES) throw new Error('Online plugin archive exceeds the 128 MB safety limit')
      await handle.write(bytes)
    }
    if (received === 0) throw new Error('Update server returned an empty plugin archive')
    return received
  } catch (error) {
    await handle?.close().catch(() => {})
    handle = undefined
    await rm(destination, { force: true }).catch(() => {})
    if (controller.signal.aborted) throw new Error('Plugin archive download timed out')
    throw error
  } finally {
    clearTimeout(timer)
    await handle?.close().catch(() => {})
  }
}

function archiveKind(fileName) {
  const lower = fileName.toLowerCase()
  if (lower.endsWith('.tar.gz')) return 'tgz'
  if (lower.endsWith('.tgz')) return 'tgz'
  if (lower.endsWith('.zip')) return 'zip'
  return undefined
}

function commandName(name) {
  return process.platform === 'win32' && name === 'pnpm' ? 'pnpm.cmd' : name
}

function runCommand(command, args, options = {}) {
  return new Promise((resolvePromise, reject) => {
    const timeoutMs = options.timeoutMs ?? COMMAND_TIMEOUT_MS
    const maxOutputBytes = options.maxOutputBytes ?? MAX_COMMAND_OUTPUT_BYTES
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: { ...process.env, CI: 'true', ...options.env },
      windowsHide: true,
      shell: options.shell === true,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    let stdout = ''
    let stderr = ''
    let outputBytes = 0
    let abortError
    let settled = false
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    const abort = (error) => {
      if (abortError !== undefined) return
      abortError = error
      child.kill('SIGKILL')
    }
    const appendOutput = (target, chunk) => {
      outputBytes += Buffer.byteLength(chunk, 'utf8')
      if (outputBytes > maxOutputBytes) {
        abort(new Error(`${command} produced more than ${String(maxOutputBytes)} bytes of output`))
        return target
      }
      return target + chunk
    }
    child.stdout.on('data', chunk => { stdout = appendOutput(stdout, chunk) })
    child.stderr.on('data', chunk => { stderr = appendOutput(stderr, chunk) })
    const timer = setTimeout(() => abort(new Error(`${command} timed out after ${String(timeoutMs)} ms`)), timeoutMs)
    const settle = (error, code) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      if (error !== undefined) {
        reject(error)
      } else if (code === 0) {
        resolvePromise({ stdout, stderr })
      } else {
        const detail = `${stdout}\n${stderr}`.trim().slice(-8000)
        reject(new Error(`${command} exited with code ${String(code)}${detail ? `\n${detail}` : ''}`))
      }
    }
    child.once('error', error => settle(error))
    child.once('close', code => settle(abortError, code))
  })
}

function archiveLines(listing) {
  return listing.split(/\r?\n/u).filter(line => line.length > 0)
}

function assertSafeArchivePath(raw) {
  if (raw.length > 1024) throw new Error('Archive contains a path longer than 1024 characters')
  if (/[\u0000-\u001f\u007f]/u.test(raw)) throw new Error('Archive contains a path with control characters')
  const name = raw.replaceAll('\\', '/')
  if (name.startsWith('/') || /^[A-Za-z]:/u.test(name)) throw new Error(`Archive contains an absolute path: ${name}`)
  const parts = name.split('/')
  for (const part of parts) {
    if (part === '' || part === '.') continue
    if (part === '..') throw new Error(`Archive contains path traversal: ${name}`)
    if (/[<>:"|?*]/u.test(part)) throw new Error(`Archive contains a Windows-unsafe path: ${name}`)
    if (/[. ]$/u.test(part)) throw new Error(`Archive contains a path ending in a dot or space: ${name}`)
    const stem = part.split('.')[0].toUpperCase()
    if (/^(?:CON|PRN|AUX|NUL|CLOCK\$|CONIN\$|CONOUT\$|COM[1-9]|LPT[1-9])$/u.test(stem)) {
      throw new Error(`Archive contains a reserved Windows path: ${name}`)
    }
  }
}

function archiveEntrySize(tokens) {
  if (tokens.length >= 5 && tokens.slice(1, 5).every(token => /^\d+$/u.test(token))) return Number(tokens[4])
  if (tokens.length >= 3 && /^\d+$/u.test(tokens[2])) return Number(tokens[2])
  return Number.NaN
}

function inspectArchiveListings(pathListing, verboseListing) {
  const paths = archiveLines(pathListing)
  const details = archiveLines(verboseListing)
  if (paths.length === 0) throw new Error('Plugin archive is empty')
  if (paths.length > MAX_EXTRACTED_FILES) throw new Error(`Archive contains more than ${String(MAX_EXTRACTED_FILES)} entries`)
  if (details.length !== paths.length) throw new Error('Unable to verify every archive entry before extraction')
  let fileCount = 0
  let totalBytes = 0
  for (let index = 0; index < paths.length; index++) {
    assertSafeArchivePath(paths[index])
    const tokens = details[index].trimStart().split(/\s+/u)
    const type = tokens[0]?.[0]
    if (type !== '-' && type !== 'd') {
      throw new Error(`Archive contains a link or unsupported entry type: ${paths[index]}`)
    }
    const size = archiveEntrySize(tokens)
    if (!Number.isSafeInteger(size) || size < 0) throw new Error(`Unable to verify archive entry size: ${paths[index]}`)
    if (type === '-') {
      fileCount += 1
      totalBytes += size
      if (fileCount > MAX_EXTRACTED_FILES) throw new Error(`Archive contains more than ${String(MAX_EXTRACTED_FILES)} files`)
      if (totalBytes > MAX_EXTRACTED_BYTES) throw new Error('Archive expands beyond the 512 MB safety limit')
    }
  }
}

function isValidPackageName(name) {
  if (typeof name !== 'string' || name.length === 0 || name.length > 214 || name !== name.toLowerCase()) return false
  const part = '[a-z0-9][a-z0-9._~-]*'
  return new RegExp(`^(?:${part}|@${part}/${part})$`, 'u').test(name)
}

async function sha256File(path) {
  return new Promise((resolvePromise, reject) => {
    const hash = createHash('sha256')
    const stream = createReadStream(path)
    stream.on('data', chunk => hash.update(chunk))
    stream.once('error', reject)
    stream.once('end', () => resolvePromise(hash.digest('hex')))
  })
}

async function inspectExtractedTree(root) {
  const candidates = []
  let fileCount = 0
  let totalBytes = 0
  async function walk(dir) {
    const entries = await readdir(dir, { withFileTypes: true })
    for (const entry of entries) {
      const full = join(dir, entry.name)
      const info = await lstat(full)
      if (info.isSymbolicLink()) throw new Error(`Archive contains a symbolic link: ${relative(root, full)}`)
      if (info.isDirectory()) {
        await walk(full)
        continue
      }
      if (!info.isFile()) continue
      fileCount += 1
      totalBytes += info.size
      if (fileCount > MAX_EXTRACTED_FILES) throw new Error(`Archive contains more than ${String(MAX_EXTRACTED_FILES)} files`)
      if (totalBytes > MAX_EXTRACTED_BYTES) throw new Error('Archive expands beyond the 512 MB safety limit')
      if (entry.name !== 'package.json') continue
      if (info.size > MAX_PACKAGE_JSON_BYTES) throw new Error('A package.json file exceeds the 1 MB safety limit')
      let manifest
      try { manifest = JSON.parse(await readFile(full, 'utf8')) } catch { continue }
      const patch = manifest?.dsh?.bundle?.patch
      if (patch !== undefined) {
        if (!isValidPackageName(manifest?.name)) throw new Error('Plugin package.json has an invalid npm package name')
        if (typeof patch !== 'string' || patch.length === 0 || patch.length > 1024) {
          throw new Error(`Plugin ${manifest.name} has an invalid dsh.bundle.patch`)
        }
        if (manifest.version !== undefined && (typeof manifest.version !== 'string' || manifest.version.length > 128)) {
          throw new Error(`Plugin ${manifest.name} has an invalid version`)
        }
        const packageDir = dirname(full)
        const patchPath = resolve(packageDir, patch)
        const boundary = `${resolve(packageDir)}${sep}`
        if (patchPath !== resolve(packageDir) && !patchPath.startsWith(boundary)) {
          throw new Error(`Plugin patch escapes its package directory: ${patch}`)
        }
        try {
          const patchInfo = await lstat(patchPath)
          if (!patchInfo.isFile()) throw new Error('not a file')
        } catch {
          throw new Error(`Plugin ${manifest.name} declares a missing dsh.bundle.patch: ${patch}`)
        }
        candidates.push({ packageDir, manifest })
      }
    }
  }
  await walk(root)
  if (candidates.length === 0) throw new Error('No installable dsh.bundle package was found in the archive')
  if (candidates.length > 1) {
    throw new Error(`Archive contains multiple installable bundles: ${candidates.map(item => item.manifest.name).join(', ')}`)
  }
  return candidates[0]
}

let CustomPluginsGateway = (() => {
  let _classSuper = TypertRemoteService
  let _instanceExtraInitializers = []
  let _listCustom_decorators
  let _setEnabled_decorators
  let _requestUpdate_decorators
  let _requestInstall_decorators
  let _refreshRepository_decorators
  let _beginInstall_decorators
  let _appendInstallChunk_decorators
  let _cancelInstall_decorators
  let _finishInstall_decorators
  return class CustomPluginsGateway extends _classSuper {
    static {
      const _metadata = typeof Symbol === 'function' && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0
      _listCustom_decorators = [Remote('listCustom')]
      __esDecorate(this, null, _listCustom_decorators, {
        kind: 'method', name: 'listCustom', static: false, private: false,
        access: { has: (obj) => 'listCustom' in obj, get: (obj) => obj.listCustom },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _setEnabled_decorators = [Remote('setEnabled')]
      __esDecorate(this, null, _setEnabled_decorators, {
        kind: 'method', name: 'setEnabled', static: false, private: false,
        access: { has: (obj) => 'setEnabled' in obj, get: (obj) => obj.setEnabled },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _requestUpdate_decorators = [Remote('requestUpdate')]
      __esDecorate(this, null, _requestUpdate_decorators, {
        kind: 'method', name: 'requestUpdate', static: false, private: false,
        access: { has: (obj) => 'requestUpdate' in obj, get: (obj) => obj.requestUpdate },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _beginInstall_decorators = [Remote('beginInstall')]
      _requestInstall_decorators = [Remote('requestInstall')]
      __esDecorate(this, null, _requestInstall_decorators, {
        kind: 'method', name: 'requestInstall', static: false, private: false,
        access: { has: (obj) => 'requestInstall' in obj, get: (obj) => obj.requestInstall }, metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _refreshRepository_decorators = [Remote('refreshRepository')]
      __esDecorate(this, null, _refreshRepository_decorators, {
        kind: 'method', name: 'refreshRepository', static: false, private: false,
        access: { has: (obj) => 'refreshRepository' in obj, get: (obj) => obj.refreshRepository }, metadata: _metadata,
      }, null, _instanceExtraInitializers)
      __esDecorate(this, null, _beginInstall_decorators, {
        kind: 'method', name: 'beginInstall', static: false, private: false,
        access: { has: (obj) => 'beginInstall' in obj, get: (obj) => obj.beginInstall },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _appendInstallChunk_decorators = [Remote('appendInstallChunk')]
      __esDecorate(this, null, _appendInstallChunk_decorators, {
        kind: 'method', name: 'appendInstallChunk', static: false, private: false,
        access: { has: (obj) => 'appendInstallChunk' in obj, get: (obj) => obj.appendInstallChunk },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _cancelInstall_decorators = [Remote('cancelInstall')]
      __esDecorate(this, null, _cancelInstall_decorators, {
        kind: 'method', name: 'cancelInstall', static: false, private: false,
        access: { has: (obj) => 'cancelInstall' in obj, get: (obj) => obj.cancelInstall },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      _finishInstall_decorators = [Remote('finishInstall')]
      __esDecorate(this, null, _finishInstall_decorators, {
        kind: 'method', name: 'finishInstall', static: false, private: false,
        access: { has: (obj) => 'finishInstall' in obj, get: (obj) => obj.finishInstall },
        metadata: _metadata,
      }, null, _instanceExtraInitializers)
      if (_metadata) Object.defineProperty(this, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata })
    }

    static inject = ['loader']

    constructor(ctx) {
      super(ctx, 'customPlugins')
      __runInitializers(this, _instanceExtraInitializers)
      this.uploads = new Map()
      this.installBusy = false
      this.catalog = new RepositoryCatalog(join(this.profileDir(), '.dsh-w-custom-plugins-catalog.json'))
      const cleanupTimer = setInterval(() => this.cleanupExpiredUploads(), UPLOAD_SWEEP_MS)
      cleanupTimer.unref?.()
      this.ctx.effect(() => () => {
        clearInterval(cleanupTimer)
        const roots = [...this.uploads.values()].map(upload => upload.root)
        this.uploads.clear()
        for (const root of roots) void rm(root, { recursive: true, force: true }).catch(() => {})
      })
    }

    /** Absolute path of the active profile's user patch file (resolved from ctx.baseUrl). */
    patchPath() {
      return fileURLToPath(new URL(PATCH_FILE, this.ctx.baseUrl))
    }

    /** Read the persisted disable entry ids from the profile patch file. */
    async readDisabledIds() {
      const ids = new Set()
      for (const patch of await readPatchArray(this.patchPath())) {
        if (!patch || typeof patch.id !== 'string' || typeof patch.disabled !== 'boolean') continue
        if (patch.disabled) ids.add(patch.id)
        else ids.delete(patch.id)
      }
      return ids
    }

    async listCustom() {
      const disabledIds = await this.readDisabledIds()
      const entries = []
      for (const entry of this.ctx.loader.entries()) {
        if (entry.options.group) continue
        if (!isCustomModule(entry.options.name)) continue
        const persistedId = profileEntryId(entry.id)
        const manifest = await this.readInstalledManifest(entry.options.name)
        entries.push({
          entryId: entry.id,
          moduleName: entry.options.name,
          enabled: !disabledIds.has(persistedId),
          version: typeof manifest?.version === 'string' ? manifest.version : '',
          protected: entry.fiber === this.ctx.fiber || entry.options.name === MANAGER_PACKAGE,
        })
      }
      const manager = this.ctx.get?.('pluginManager')
      if (typeof manager?.listBundles === 'function') {
        for (const bundle of await manager.listBundles()) {
          if (!bundle.installed || !isCustomModule(bundle.name) || entries.some(entry => entry.moduleName === bundle.name)) continue
          entries.push({ entryId: `bundle:${bundle.name}`, moduleName: bundle.name, bundleName: bundle.name,
            version: bundle.version ?? '', enabled: bundle.enabled, protected: bundle.name === MANAGER_PACKAGE })
        }
      }
      const catalog = await this.catalog.snapshot()
      return { entries: mergeCatalog(entries, catalog.entries), repositoryWarning: catalog.warning }
    }

    async refreshRepository() {
      const catalog = await this.catalog.snapshot(true)
      const snapshot = await this.listCustom()
      return { ...snapshot, repositoryWarning: catalog.warning }
    }

    async requestInstall(moduleName) {
      if (this.installBusy || this.uploads.size > 0) throw new Error('Another plugin installation is already in progress')
      this.installBusy = true
      let root
      try {
        const snapshot = await this.catalog.snapshot()
        const entry = snapshot.entries.find(item => item.moduleName === moduleName)
        if (!entry) throw new Error('Plugin is not listed in the W repository: ' + String(moduleName))
        if (await this.readInstalledManifest(moduleName)) return { status: 'already-installed', packageName: moduleName }
        root = await mkdtemp(join(tmpdir(), 'dsh-plugin-repository-'))
        const archivePath = join(root, `${moduleName}-${entry.version}.tgz`)
        await retryRemote(() => downloadRepositoryArchive(entry, archivePath))
        return { status: 'installed', ...await this.installArchive(root, archivePath, 'tgz', { packageName: moduleName, version: entry.version }) }
      } finally {
        this.installBusy = false
        if (root !== undefined) await rm(root, { recursive: true, force: true })
      }
    }

    async setEnabled(entryId, enabled) {
      if (typeof entryId !== 'string' || entryId.length === 0) throw new Error('entryId must be a non-empty string')
      if (typeof enabled !== 'boolean') throw new Error('enabled must be a boolean')
      if (entryId.startsWith('bundle:')) {
        const moduleName = entryId.slice(7)
        if (!isCustomModule(moduleName) || moduleName === MANAGER_PACKAGE || !(await this.readInstalledManifest(moduleName))) throw new Error('Custom plugin bundle not found')
        const manager = this.ctx.get?.('pluginManager')
        if (typeof manager?.setBundleEnabled !== 'function') throw new Error('Bundle enablement is unavailable')
        const result = await manager.setBundleEnabled(moduleName, enabled)
        if (result.error || result.application === 'failed') throw new Error(result.error?.diagnostic || result.error?.code || 'Bundle enablement failed')
        return { entryId, enabled }
      }
      let target
      for (const entry of this.ctx.loader.entries()) {
        if (entry.options.group || entry.id !== entryId) continue
        target = entry
        break
      }
      if (!target || !isCustomModule(target.options.name)) throw new Error('Custom plugin entry not found: ' + entryId)
      if (target.fiber === this.ctx.fiber || target.options.name === MANAGER_PACKAGE) {
        throw new Error('The custom plugin manager cannot disable itself')
      }

      const persistedId = profileEntryId(entryId)
      const wasEnabled = !target.disabled
      if (enabled !== wasEnabled) await target.update({ disabled: !enabled })
      try {
        await mutatePatchArray(this.patchPath(), data => updateDisabledPatch(data, persistedId, entryId, enabled))
      } catch (error) {
        if (enabled !== wasEnabled) {
          try { await target.update({ disabled: !wasEnabled }) } catch {}
        }
        throw error
      }
      return { entryId, enabled }
    }

    profileDir() {
      return dirname(this.patchPath())
    }

    async readInstalledManifest(moduleName) {
      if (!isValidPackageName(moduleName)) return undefined
      const packagePath = join(this.profileDir(), 'node_modules', ...moduleName.split('/'), 'package.json')
      try {
        const raw = await readFile(packagePath, 'utf8')
        if (Buffer.byteLength(raw, 'utf8') > MAX_PACKAGE_JSON_BYTES) throw new Error('Installed package.json exceeds the 1 MB safety limit')
        const manifest = JSON.parse(raw)
        return manifest?.name === moduleName ? manifest : undefined
      } catch (error) {
        if (error && error.code === 'ENOENT') return undefined
        throw error
      }
    }

    async resolveUpdateSource(moduleName) {
      if (moduleName.startsWith('dsh-w-')) {
        const snapshot = await this.catalog.snapshot()
        const entry = snapshot.entries.find(item => item.moduleName === moduleName)
        if (!entry || entry.archiveSha === null) return undefined
        return { version: entry.version, catalogEntry: entry, source: 'w-ecosystem' }
      }

      const hosts = new Set(['registry.npmjs.org'])
      const registryUrl = `https://registry.npmjs.org/${encodeURIComponent(moduleName)}/latest`
      const manifest = await retryRemote(() => fetchRemoteJson(registryUrl, hosts, true))
      if (manifest === undefined) return undefined
      if (manifest?.name !== moduleName || typeof manifest?.version !== 'string' || typeof manifest?.dist?.tarball !== 'string') {
        throw new Error('npm update manifest does not match the installed package')
      }
      return {
        version: manifest.version,
        url: assertTrustedHttpsUrl(manifest.dist.tarball, hosts),
        hosts,
        source: 'npm',
      }
    }

    async installArchive(root, archivePath, kind, expected = {}) {
      const [listing, verboseListing] = await Promise.all([
        runCommand('tar.exe', ['-tf', archivePath]),
        runCommand('tar.exe', ['-tvf', archivePath]),
      ])
      inspectArchiveListings(listing.stdout, verboseListing.stdout)
      const extracted = join(root, 'extracted')
      await mkdir(extracted, { recursive: true })
      await runCommand('tar.exe', ['--no-same-owner', '--no-same-permissions', '-xf', archivePath, '-C', extracted])
      const candidate = await inspectExtractedTree(extracted)
      if (expected.packageName !== undefined && candidate.manifest.name !== expected.packageName) {
        throw new Error(`Downloaded archive contains ${candidate.manifest.name}, expected ${expected.packageName}`)
      }
      if (expected.version !== undefined && candidate.manifest.version !== expected.version) {
        throw new Error(`Downloaded archive version does not match the update manifest (${String(candidate.manifest.version)} != ${expected.version})`)
      }
      let installPath = archivePath
      if (kind === 'zip') {
        const packed = join(root, 'packed')
        await mkdir(packed, { recursive: true })
        await runCommand(commandName('pnpm'), ['pack', '--config.ignore-scripts=true', '--pack-destination', packed], {
          cwd: candidate.packageDir,
          env: { npm_config_ignore_scripts: 'true' },
          shell: process.platform === 'win32',
        })
        const tarballs = (await readdir(packed)).filter(name => name.toLowerCase().endsWith('.tgz'))
        if (tarballs.length !== 1) throw new Error('Packing the ZIP plugin did not produce exactly one .tgz archive')
        installPath = join(packed, tarballs[0])
      }
      const profileDir = this.profileDir()
      const digest = (await sha256File(installPath)).slice(0, 12)
      const archiveDir = join(profileDir, '.plugin-archives')
      await mkdir(archiveDir, { recursive: true })
      const packageDigest = createHash('sha256').update(candidate.manifest.name).digest('hex').slice(0, 8)
      const safePackage = candidate.manifest.name.replace(/[^A-Za-z0-9._-]/gu, '_').slice(0, 80)
      const packageKey = `${safePackage}-${packageDigest}`
      const safeVersion = typeof candidate.manifest.version === 'string'
        ? candidate.manifest.version.replace(/[^A-Za-z0-9._-]/gu, '_').slice(0, 80)
        : '0.0.0'
      const durableArchive = join(archiveDir, `${packageKey}-${safeVersion}-${digest}.tgz`)
      await copyFile(installPath, durableArchive)
      let result
      try {
        result = await installWithHarness(this.ctx, durableArchive, async () => {
          const dshEntry = process.argv[1]
          if (typeof dshEntry !== 'string' || !dshEntry) throw new Error('Unable to locate the running dsh CLI entry')
          return runCommand(process.execPath, [dshEntry,
          'plugin',
          '--profile',
          basename(profileDir),
          'add',
          durableArchive,
          ], { cwd: profileDir })
        })
      } catch (error) {
        // Activation can fail after installation; retain a referenced file: archive.
        throw error
      }
      for (const oldName of await readdir(archiveDir)) {
        if (oldName === basename(durableArchive)) continue
        if (oldName.startsWith(`${packageKey}-`) && oldName.toLowerCase().endsWith('.tgz')) {
          await rm(join(archiveDir, oldName), { force: true })
        }
      }
      return {
        packageName: candidate.manifest.name,
        version: typeof candidate.manifest.version === 'string' ? candidate.manifest.version : '',
        ...result,
        output: result.output.slice(-4000),
      }
    }

    async requestUpdate(entryId) {
      if (typeof entryId !== 'string' || entryId.length === 0) throw new Error('entryId must be a non-empty string')
      if (this.installBusy || this.uploads.size > 0) throw new Error('Another plugin installation is already in progress')
      let target
      for (const entry of this.ctx.loader.entries()) {
        if (!entry.options.group && entry.id === entryId) {
          target = entry
          break
        }
      }
      const moduleName = target?.options.name ?? (entryId.startsWith('bundle:') ? entryId.slice(7) : undefined)
      if (!isCustomModule(moduleName)) {
        throw new Error('Custom plugin entry not found: ' + entryId)
      }
      this.installBusy = true
      let root
      try {
        const installed = await this.readInstalledManifest(moduleName)
        if (!installed) throw new Error('Custom plugin entry not found: ' + entryId)
        const installedVersion = typeof installed?.version === 'string' ? installed.version : ''
        const source = await this.resolveUpdateSource(moduleName)
        if (source === undefined) return { status: 'unavailable', packageName: moduleName, installedVersion }
        if (installedVersion === source.version) {
          return { status: 'up-to-date', packageName: moduleName, installedVersion, latestVersion: source.version }
        }
        if (installedVersion !== '') {
          const comparison = compareSemver(source.version, installedVersion)
          if (comparison === undefined) throw new Error(`Cannot safely compare plugin versions ${installedVersion} and ${source.version}`)
          if (comparison < 0) {
            return { status: 'up-to-date', packageName: moduleName, installedVersion, latestVersion: source.version }
          }
        }
        root = await mkdtemp(join(tmpdir(), 'dsh-plugin-update-'))
        const archivePath = join(root, `${moduleName.replace(/[^A-Za-z0-9._-]/gu, '_')}-${source.version.replace(/[^A-Za-z0-9._-]/gu, '_')}.tgz`)
        await retryRemote(() => source.catalogEntry
          ? downloadRepositoryArchive(source.catalogEntry, archivePath)
          : downloadRemoteArchive(source.url, archivePath, source.hosts))
        const result = await this.installArchive(root, archivePath, 'tgz', {
          packageName: moduleName,
          version: source.version,
        })
        return {
          status: 'updated',
          previousVersion: installedVersion,
          latestVersion: source.version,
          source: source.source,
          ...result,
        }
      } finally {
        this.installBusy = false
        if (root !== undefined) await rm(root, { recursive: true, force: true })
      }
    }

    cleanupExpiredUploads() {
      const cutoff = Date.now() - UPLOAD_TTL_MS
      for (const [uploadId, upload] of this.uploads) {
        if (upload.busy || upload.updatedAt >= cutoff) continue
        this.uploads.delete(uploadId)
        void rm(upload.root, { recursive: true, force: true }).catch(() => {})
      }
    }

    async beginInstall(fileName, size) {
      this.cleanupExpiredUploads()
      if (this.installBusy || this.uploads.size >= 1) throw new Error('Another plugin installation is already in progress')
      if (typeof fileName !== 'string' || archiveKind(fileName) === undefined) {
        throw new Error('Supported plugin archives: .tgz, .tar.gz, and .zip')
      }
      if (!Number.isSafeInteger(size) || size <= 0 || size > MAX_UPLOAD_BYTES) {
        throw new Error('Plugin archive must be between 1 byte and 128 MB')
      }
      const root = await mkdtemp(join(tmpdir(), 'dsh-plugin-upload-'))
      const safeName = basename(fileName).replace(/[^A-Za-z0-9._-]/gu, '_')
      const archivePath = join(root, safeName || 'plugin.tgz')
      await writeFile(archivePath, '')
      const uploadId = randomUUID()
      this.uploads.set(uploadId, {
        archivePath,
        busy: false,
        createdAt: Date.now(),
        fileName,
        kind: archiveKind(fileName),
        nextIndex: 0,
        received: 0,
        root,
        size,
        updatedAt: Date.now(),
      })
      return { uploadId, maxChunkBytes: MAX_CHUNK_BYTES }
    }

    async appendInstallChunk(uploadId, index, base64) {
      if (typeof uploadId !== 'string') throw new Error('Plugin upload id is invalid')
      const upload = this.uploads.get(uploadId)
      if (upload === undefined) throw new Error('Plugin upload session expired')
      if (upload.busy) throw new Error('Another operation is already using this upload session')
      if (!Number.isSafeInteger(index) || index !== upload.nextIndex) throw new Error('Plugin upload chunks arrived out of order')
      if (typeof base64 !== 'string' || base64.length === 0 || base64.length > MAX_BASE64_CHARS) {
        throw new Error('Plugin upload chunk has an invalid encoded size')
      }
      if (base64.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(base64)) {
        throw new Error('Plugin upload chunk is not valid base64')
      }
      upload.busy = true
      try {
        const chunk = Buffer.from(base64, 'base64')
        if (chunk.length === 0 || chunk.length > MAX_CHUNK_BYTES || chunk.toString('base64') !== base64) {
          throw new Error('Plugin upload chunk has an invalid size or encoding')
        }
        if (upload.received + chunk.length > upload.size) throw new Error('Plugin upload exceeds its declared size')
        await appendFile(upload.archivePath, chunk)
        upload.received += chunk.length
        upload.nextIndex += 1
        upload.updatedAt = Date.now()
        return { received: upload.received, size: upload.size }
      } finally {
        upload.busy = false
      }
    }

    async cancelInstall(uploadId) {
      if (typeof uploadId !== 'string') throw new Error('Plugin upload id is invalid')
      const upload = this.uploads.get(uploadId)
      if (upload === undefined) return { cancelled: false }
      if (upload.busy) throw new Error('Another operation is already using this upload session')
      this.uploads.delete(uploadId)
      await rm(upload.root, { recursive: true, force: true })
      return { cancelled: true }
    }

    async finishInstall(uploadId) {
      if (typeof uploadId !== 'string') throw new Error('Plugin upload id is invalid')
      const upload = this.uploads.get(uploadId)
      if (upload === undefined) throw new Error('Plugin upload session expired')
      if (upload.busy || this.installBusy) throw new Error('Another operation is already using this upload session')
      upload.busy = true
      this.installBusy = true
      this.uploads.delete(uploadId)
      try {
        if (upload.received !== upload.size) {
          throw new Error(`Plugin upload is incomplete: ${String(upload.received)}/${String(upload.size)} bytes`)
        }
        return await this.installArchive(upload.root, upload.archivePath, upload.kind)
      } finally {
        this.installBusy = false
        await rm(upload.root, { recursive: true, force: true })
      }
    }
  }
})()

export {
  CustomPluginsGateway,
  CustomPluginsGateway as default,
  assertSafeArchivePath,
  inspectArchiveListings,
  isValidPackageName,
  updateDisabledPatch,
}
