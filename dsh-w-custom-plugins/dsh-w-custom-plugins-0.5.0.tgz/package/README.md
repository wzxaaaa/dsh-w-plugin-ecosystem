# dsh-w-custom-plugins

DeepSeek Harness 插件管理器：在「设置 → 插件」页新增「自定义插件」标签页，管理你自己挂载的插件。

## 功能

- 列出所有非 `@deepseek-ai/*` 的已安装包插件，并隐藏 preset 内部的相对路径实现模块；
- 自动读取 GitHub 仓库 `wzxaaaa/dsh-w-plugin-ecosystem` 的所有 W 系列插件：未安装时显示小下载图标，点击后下载并安装；已安装时保留更新、设置和启停布局；
- 新版官方 Desktop/Web 通过共用 `pluginManager.installBundle()` 服务安装，等同官方「添加插件」入口的安装流程；旧源码版保留 CLI 安装方式；
- 仓库目录缓存十分钟，支持手动刷新；断网时保留已安装插件和缓存并显示原因。未发布对应版本 `.tgz` 的插件会显示禁用的下载图标；
- 已安装的插件保留启/停开关，**切换即时生效**；管理器自身的停用开关受保护；
- 已安装的插件卡片提供“检查并更新”图标：W 系列插件从 `wzxaaaa/dsh-w-plugin-ecosystem` 获取最新版，其他包尝试 npm `latest`；下载后复用安全校验与官方安装流程，按实际结果提示生效、重启或加载警告；
- **拖拽安装**：把 `.tgz` / `.tar.gz` / `.zip` 插件压缩包拖进标签页（或点选），自动校验并调用 Harness 安装服务（旧版使用 `dsh plugin add`）；
- 解压前校验包内**恰好一个**带合法 `dsh.bundle.patch` 的插件，拒绝路径穿越、链接、Windows 非法路径及超限压缩包；
- 上传失败或离开页面时自动取消并清理临时文件，过期会话也会后台回收。

> ⚠️ 插件拥有本机代码执行权限，请只安装可信来源的压缩包。

## 安装

```powershell
pnpm pack
dsh plugin --profile web add ./dsh-w-custom-plugins-0.5.0.tgz
```

安装后重启桌面版（或 `dsh web`）即随 `web` profile 自启。

官方桌面版使用 `desktop` profile，安装时将上面的 `--profile web` 改为 `--profile desktop`。

官方桌面版也可直接在「添加插件」中填写本插件的 `.tgz` 绝对路径完成首次安装或升级。安装后打开「设置 → 插件 → 自定义插件」，再点击仓库插件卡片的下载图标安装其余插件。是否需要重启、是否出现加载警告以官方服务的实际结果为准。目录中出现插件只代表仓库已发布，不代表该插件已经适配当前 Harness。

`0.4.2` 修复新版官方 Harness 的 `strict codec has no create() factory` 加载错误，同时保留旧版源码运行时需要的 `schema.parse()` 接口。

## 卸载

```powershell
dsh plugin --profile web remove dsh-w-custom-plugins
```
