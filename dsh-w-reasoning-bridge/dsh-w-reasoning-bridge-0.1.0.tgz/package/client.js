window.__ModuleLoader__.load({
  id: "dsh-w-reasoning-bridge",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");

    var LEVELS = ["off", "minimal", "low", "medium", "high", "xhigh", "max"];
    var FORMATS = ["openai", "deepseek", "openrouter", "together", "baseten", "zai", "qwen", "chat-template", "qwen-chat-template", "string-thinking", "ant-ling"];
    var MANAGED_COMPAT = ["thinkingFormat", "supportsReasoningEffort", "supportsDeveloperRole"];
    var PRESETS = [
      { id: "openai", label: "OpenAI reasoning_effort", description: "顶层 reasoning_effort", format: "openai", effortField: true, efforts: { off: "none", minimal: "minimal", low: "low", medium: "medium", high: "high", xhigh: "xhigh", max: "max" } },
      { id: "deepseek", label: "DeepSeek thinking", description: "thinking.type 开关", format: "deepseek", effortField: false, efforts: { off: null, high: "high" } },
      { id: "openrouter", label: "OpenRouter reasoning", description: "reasoning.effort", format: "openrouter", effortField: false, efforts: { off: "none", low: "low", medium: "medium", high: "high", xhigh: "xhigh" } },
      { id: "qwen", label: "Qwen enable_thinking", description: "enable_thinking 开关", format: "qwen", effortField: false, efforts: { off: null, high: "high" } },
      { id: "zai", label: "Z.ai / GLM thinking", description: "thinking.type 开关", format: "zai", effortField: false, efforts: { off: null, high: "high" } },
      { id: "together", label: "Together reasoning", description: "reasoning.enabled 开关", format: "together", effortField: false, efforts: { off: null, high: "high" } },
      { id: "string-thinking", label: "字符串 thinking", description: "thinking = 字符串", format: "string-thinking", effortField: false, efforts: { off: "off", low: "low", medium: "medium", high: "high" } },
      { id: "anthropic", label: "Anthropic 原生推理", description: "原生 thinking budget", format: "", effortField: null, developerRole: null, efforts: { off: null, low: "low", medium: "medium", high: "high", max: "max" } },
      { id: "passthrough", label: "仅 reasoning_effort", description: "不声明特殊方言", format: "", effortField: true, efforts: { off: "none", low: "low", medium: "medium", high: "high" } },
    ];

    var CSS = [
      ".rwb-root{display:flex;flex-direction:column;gap:16px;padding:20px;max-width:980px}",
      ".rwb-hero{display:flex;gap:14px;align-items:flex-start;padding:17px 18px;border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:linear-gradient(135deg,color-mix(in srgb,var(--dsw-alias-state-business-primary) 10%,var(--dsw-alias-bg-layer-1)),var(--dsw-alias-bg-layer-1))}",
      ".rwb-hero-icon{display:flex;align-items:center;justify-content:center;flex:none;width:42px;height:42px;border-radius:12px;background:var(--dsw-alias-state-business-primary);color:#fff;font-size:22px}",
      ".rwb-hero h2{font-size:18px;line-height:25px;margin:0 0 4px}.rwb-hero p,.rwb-hint{font-size:12px;line-height:19px;color:var(--dsw-alias-label-secondary);margin:0}",
      ".rwb-card{display:flex;flex-direction:column;gap:14px;padding:16px;border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-layer-1)}",
      ".rwb-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.rwb-field{display:flex;flex-direction:column;gap:6px;min-width:0}.rwb-wide{grid-column:1/-1}",
      ".rwb-label{font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary)}",
      ".rwb-input,.rwb-select{box-sizing:border-box;width:100%;height:38px;padding:0 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:9px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;outline:none}",
      ".rwb-input:focus,.rwb-select:focus{border-color:var(--dsw-alias-state-business-primary);box-shadow:0 0 0 2px color-mix(in srgb,var(--dsw-alias-state-business-primary) 16%,transparent)}",
      ".rwb-modes{display:flex;gap:7px;flex-wrap:wrap}.rwb-chip{height:34px;padding:0 12px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;cursor:pointer}.rwb-chip[data-active=true]{border-color:var(--dsw-alias-state-business-primary);background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);color:var(--dsw-alias-state-business-primary);font-weight:600}",
      ".rwb-section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.rwb-section-title{font-size:14px;font-weight:650}.rwb-efforts{display:flex;flex-direction:column;border:1px solid var(--dsw-alias-border-l1);border-radius:11px;overflow:hidden}.rwb-effort{display:grid;grid-template-columns:24px minmax(90px,.55fr) minmax(140px,1fr);gap:10px;align-items:center;padding:9px 11px;border-top:1px solid var(--dsw-alias-border-l1)}.rwb-effort:first-child{border-top:0}.rwb-effort-name{font-size:13px;font-weight:600}.rwb-effort input[type=checkbox]{width:16px;height:16px}",
      ".rwb-actions{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.rwb-button{height:36px;padding:0 14px;border:1px solid var(--dsw-alias-border-l2);border-radius:9px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;cursor:pointer}.rwb-button[data-primary=true]{border-color:transparent;background:var(--dsw-alias-state-business-primary);color:#fff;font-weight:600}.rwb-button:disabled,.rwb-chip:disabled,.rwb-input:disabled,.rwb-select:disabled{opacity:.5;cursor:default}",
      ".rwb-status{font-size:12px;line-height:18px;margin:0}.rwb-status[data-error=true]{color:var(--dsw-alias-state-error-primary)}.rwb-status[data-ok=true]{color:var(--dsw-alias-state-success-primary)}",
      ".rwb-empty{padding:28px;text-align:center;color:var(--dsw-alias-label-tertiary);font-size:13px}.rwb-warning{padding:10px 12px;border-radius:9px;background:color-mix(in srgb,var(--dsw-alias-state-warning-primary,#b45309) 10%,transparent);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:19px}",
      "@media(max-width:720px){.rwb-root{padding:14px}.rwb-grid{grid-template-columns:1fr}.rwb-wide{grid-column:auto}.rwb-effort{grid-template-columns:24px 75px minmax(0,1fr)}}",
    ].join("\n");
    var tagId = "dsh-w-reasoning-bridge/styles";

    function installStyle() {
      if (typeof document === "undefined") return null;
      var node = document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]");
      if (!node) {
        node = document.createElement("style");
        node.dataset.plugin = "dsh-w-reasoning-bridge";
        node.dataset.pluginCss = tagId;
        document.head.appendChild(node);
      }
      node.textContent = CSS;
      return node;
    }

    function isRecord(value) { return !!value && typeof value === "object" && !Array.isArray(value); }
    function record(value) { return isRecord(value) ? value : {}; }
    function clone(value) { return value === undefined ? undefined : structuredClone(value); }
    function profileOf(layer, provider) { return record(record(record(layer).providers)[provider]); }
    function modelEntry(profile, model) {
      var models = Array.isArray(profile.models) ? profile.models : [];
      var index = models.findIndex(function (entry) { return record(entry).id === model; });
      if (index >= 0) return { kind: "models", index: index, value: record(models[index]) };
      return { kind: "override", value: record(record(profile.modelOverrides)[model]) };
    }
    function currentDraft(namespace, provider, model) {
      var profile = profileOf(record(namespace).value, provider);
      var value = modelEntry(profile, model).value;
      var compat = record(value.compat);
      var raw = value.reasoningEfforts;
      var mode = raw === false ? "disabled" : isRecord(raw) && Object.keys(raw).length ? "enabled" : "inherit";
      var efforts = {};
      if (isRecord(raw)) LEVELS.forEach(function (level) {
        if (raw[level] === null || typeof raw[level] === "string") efforts[level] = raw[level];
      });
      return {
        mode: mode,
        efforts: efforts,
        format: typeof compat.thinkingFormat === "string" ? compat.thinkingFormat : "",
        effortField: typeof compat.supportsReasoningEffort === "boolean" ? compat.supportsReasoningEffort : null,
        developerRole: typeof compat.supportsDeveloperRole === "boolean" ? compat.supportsDeveloperRole : null,
        defaultEffort: typeof profile.reasoning === "string" ? profile.reasoning : "",
      };
    }
    function validateDraft(draft) {
      if (draft.mode !== "enabled") return null;
      var enabled = LEVELS.filter(function (level) { return Object.prototype.hasOwnProperty.call(draft.efforts, level); });
      if (!enabled.some(function (level) { return level !== "off"; })) return "至少启用一个非 off 的推理强度。";
      for (var i = 0; i < enabled.length; i++) {
        var level = enabled[i];
        var wire = draft.efforts[level];
        if (level === "off" && wire === null) continue;
        if (typeof wire !== "string" || !wire.trim()) return level + " 需要填写中转站接收的值。";
      }
      if (draft.defaultEffort && !enabled.includes(draft.defaultEffort)) return "默认强度必须是当前已启用的强度。";
      return null;
    }
    function configuredModel(previous, draft) {
      var next = clone(previous) || {};
      var compat = Object.assign({}, record(next.compat));
      if (draft.mode === "inherit") {
        delete next.reasoningEfforts;
        MANAGED_COMPAT.forEach(function (field) { delete compat[field]; });
      } else if (draft.mode === "disabled") {
        next.reasoningEfforts = false;
        MANAGED_COMPAT.forEach(function (field) { delete compat[field]; });
      } else {
        next.reasoningEfforts = {};
        LEVELS.forEach(function (level) {
          if (!Object.prototype.hasOwnProperty.call(draft.efforts, level)) return;
          var value = draft.efforts[level];
          next.reasoningEfforts[level] = typeof value === "string" ? value.trim() : value;
        });
        if (draft.format) compat.thinkingFormat = draft.format; else delete compat.thinkingFormat;
        if (typeof draft.effortField === "boolean") compat.supportsReasoningEffort = draft.effortField; else delete compat.supportsReasoningEffort;
        if (typeof draft.developerRole === "boolean") compat.supportsDeveloperRole = draft.developerRole; else delete compat.supportsDeveloperRole;
      }
      if (Object.keys(compat).length) next.compat = compat; else delete next.compat;
      return next;
    }
    function buildOps(namespace, provider, model, draft) {
      var failure = validateDraft(draft);
      if (failure) throw new Error(failure);
      var valueProfile = profileOf(record(namespace).value, provider);
      var userProfile = profileOf(record(namespace).user, provider);
      var valueLocation = modelEntry(valueProfile, model);
      var userLocation = modelEntry(userProfile, model);
      var base = ["providers", provider];
      var ops = [];
      if (valueLocation.kind === "models") {
        var source = Array.isArray(userProfile.models) && userLocation.kind === "models" ? clone(userProfile.models) : clone(valueProfile.models);
        var index = source.findIndex(function (entry) { return record(entry).id === model; });
        if (index < 0) throw new Error("模型不在当前提供方的显式模型列表中。");
        source[index] = configuredModel(record(source[index]), draft);
        ops.push({ op: "set", path: base.concat(["models"]), value: source });
      } else {
        var target = base.concat(["modelOverrides", model]);
        var previous = userLocation.kind === "override" && Object.keys(userLocation.value).length ? userLocation.value : valueLocation.value;
        var next = configuredModel(previous, draft);
        if (draft.mode === "inherit" && !Object.keys(next).length) ops.push({ op: "unset", path: target });
        else ops.push({ op: "set", path: target, value: next });
      }
      if (draft.defaultEffort === "") ops.push({ op: "unset", path: base.concat(["reasoning"]) });
      else ops.push({ op: "set", path: base.concat(["reasoning"]), value: draft.defaultEffort });
      return ops;
    }
    function applyPreset(preset, previousDefault) {
      return {
        mode: "enabled",
        efforts: Object.assign({}, preset.efforts),
        format: preset.format,
        effortField: preset.effortField,
        developerRole: preset.developerRole === undefined ? false : preset.developerRole,
        defaultEffort: previousDefault && Object.prototype.hasOwnProperty.call(preset.efforts, previousDefault) ? previousDefault : "",
      };
    }
    function unique(values) {
      return Array.from(new Set(values.filter(function (value) { return typeof value === "string" && value.length > 0; })));
    }
    function messageOf(error) { return error instanceof Error ? error.message : String(error); }

    function BridgeSection(props) {
      var t = props.t;
      var stateSlot = React.useState({ status: "loading", namespace: null, providers: [], groups: [], writable: false, error: null });
      var state = stateSlot[0], setState = stateSlot[1];
      var providerSlot = React.useState("");
      var provider = providerSlot[0], setProvider = providerSlot[1];
      var modelSlot = React.useState("");
      var model = modelSlot[0], setModel = modelSlot[1];
      var draftSlot = React.useState({ mode: "inherit", efforts: {}, format: "", effortField: null, developerRole: null, defaultEffort: "" });
      var draft = draftSlot[0], setDraft = draftSlot[1];
      var presetSlot = React.useState("openai");
      var presetId = presetSlot[0], setPresetId = presetSlot[1];
      var busySlot = React.useState(false);
      var busy = busySlot[0], setBusy = busySlot[1];
      var noticeSlot = React.useState(null);
      var notice = noticeSlot[0], setNotice = noticeSlot[1];

      var load = React.useCallback(async function () {
        setState(function (old) { return Object.assign({}, old, { status: "loading", error: null }); });
        try {
          var results = await Promise.all([
            props.describeSettings(), props.listConfigurableProviders(), props.modelCatalog(),
          ]);
          var described = results[0], directory = results[1], catalog = results[2];
          var namespace = (described.namespaces || []).find(function (entry) { return entry.ns === "llm-pi-ai"; });
          if (!namespace) throw new Error("未找到 llm-pi-ai 设置。请先启用 Pi-AI 模型适配器。");
          var configured = Object.keys(record(record(namespace.value).providers));
          var rows = (directory || []).filter(function (entry) { return entry.settingsNs === "llm-pi-ai"; });
          var providers = unique(rows.map(function (entry) { return entry.provider; }).concat(configured)).map(function (id) {
            var row = rows.find(function (entry) { return entry.provider === id; });
            return { id: id, name: row && row.displayName ? row.displayName : id, declared: !!(row && row.declared) };
          });
          setState({ status: "ready", namespace: namespace, providers: providers, groups: catalog.groups || [], writable: described.writable === true, error: null });
          setProvider(function (current) { return providers.some(function (entry) { return entry.id === current; }) ? current : (providers[0] ? providers[0].id : ""); });
        } catch (error) {
          setState(function (old) { return Object.assign({}, old, { status: "error", error: messageOf(error) }); });
        }
      }, []);

      React.useEffect(function () { void load(); }, [load]);

      var selectedProfile = state.namespace ? profileOf(state.namespace.value, provider) : {};
      var group = state.groups.find(function (entry) { return entry.id === provider; });
      var models = unique(
        (group ? group.models.map(function (entry) { return entry.id; }) : [])
          .concat(Array.isArray(selectedProfile.models) ? selectedProfile.models.map(function (entry) { return record(entry).id; }) : [])
          .concat(Object.keys(record(selectedProfile.modelOverrides))),
      );

      React.useEffect(function () {
        setModel(function (current) { return models.includes(current) ? current : (models[0] || ""); });
      }, [provider, models.join("\u0000")]);

      React.useEffect(function () {
        if (!state.namespace || !provider || !model) return;
        setDraft(currentDraft(state.namespace, provider, model));
        setNotice(null);
      }, [state.namespace, provider, model]);

      var patchDraft = function (patch) { setDraft(function (current) { return Object.assign({}, current, patch); }); setNotice(null); };
      var choosePreset = function (id) {
        setPresetId(id);
        var preset = PRESETS.find(function (entry) { return entry.id === id; });
        if (preset) setDraft(function (current) { return applyPreset(preset, current.defaultEffort); });
        setNotice(null);
      };
      var toggleLevel = function (level, checked) {
        var efforts = Object.assign({}, draft.efforts);
        if (!checked) delete efforts[level];
        else efforts[level] = level === "off" ? null : level;
        var nextDefault = draft.defaultEffort && !Object.prototype.hasOwnProperty.call(efforts, draft.defaultEffort) ? "" : draft.defaultEffort;
        patchDraft({ efforts: efforts, defaultEffort: nextDefault });
      };
      var setWire = function (level, value) {
        var efforts = Object.assign({}, draft.efforts);
        efforts[level] = level === "off" && value === "" ? null : value;
        patchDraft({ efforts: efforts });
      };
      var save = async function () {
        setBusy(true); setNotice(null);
        try {
          if (!state.namespace) throw new Error("设置尚未加载。");
          if (!provider || !model) throw new Error("请选择提供方和模型。");
          var failure = validateDraft(draft);
          if (failure) throw new Error(failure);
          var answer = await props.mutateSettings("llm-pi-ai", buildOps(state.namespace, provider, model, draft), state.namespace.revision);
          if (!answer.ok) throw new Error(answer.error && answer.error.message ? answer.error.message : "设置写入失败");
          setNotice({ ok: true, text: "已保存。下一次模型解析会使用新协议，DSH 原生强度选择器也会同步更新。" });
          await load();
        } catch (error) {
          setNotice({ ok: false, text: messageOf(error) });
        } finally { setBusy(false); }
      };

      if (state.status === "loading" && !state.namespace) return React.createElement("div", { className: "rwb-empty" }, t("loading"));
      if (state.status === "error" && !state.namespace) return React.createElement("div", { className: "rwb-root" },
        React.createElement("p", { className: "rwb-status", "data-error": true }, state.error),
        React.createElement("button", { className: "rwb-button", onClick: function () { void load(); } }, t("retry"))
      );

      var selectedPreset = PRESETS.find(function (entry) { return entry.id === presetId; }) || PRESETS[0];
      var enabledLevels = LEVELS.filter(function (level) { return Object.prototype.hasOwnProperty.call(draft.efforts, level); });
      var disabled = busy || !state.writable;

      return React.createElement("div", { className: "rwb-root" },
        React.createElement("div", { className: "rwb-hero" },
          React.createElement("div", { className: "rwb-hero-icon", "aria-hidden": true }, "↯"),
          React.createElement("div", null,
            React.createElement("h2", null, t("title")),
            React.createElement("p", null, t("intro"))
          )
        ),
        React.createElement("section", { className: "rwb-card" },
          React.createElement("div", { className: "rwb-grid" },
            React.createElement("label", { className: "rwb-field" },
              React.createElement("span", { className: "rwb-label" }, t("provider")),
              React.createElement("select", { className: "rwb-select", value: provider, disabled: busy, onChange: function (event) { setProvider(event.target.value); } },
                state.providers.map(function (entry) { return React.createElement("option", { key: entry.id, value: entry.id }, entry.name + " (" + entry.id + ")"); })
              )
            ),
            React.createElement("label", { className: "rwb-field" },
              React.createElement("span", { className: "rwb-label" }, t("model")),
              React.createElement("input", { className: "rwb-input", list: "rwb-models", value: model, disabled: busy, placeholder: "model-id", onChange: function (event) { setModel(event.target.value); } }),
              React.createElement("datalist", { id: "rwb-models" }, models.map(function (id) { return React.createElement("option", { key: id, value: id }); }))
            ),
            React.createElement("label", { className: "rwb-field rwb-wide" },
              React.createElement("span", { className: "rwb-label" }, t("preset")),
              React.createElement("select", { className: "rwb-select", value: presetId, disabled: disabled, onChange: function (event) { choosePreset(event.target.value); } },
                PRESETS.map(function (entry) { return React.createElement("option", { key: entry.id, value: entry.id }, entry.label + " — " + entry.description); })
              )
            )
          ),
          state.providers.length === 0 ? React.createElement("div", { className: "rwb-warning" }, t("noProviders")) : null,
          React.createElement("div", { className: "rwb-section-head" },
            React.createElement("div", null,
              React.createElement("div", { className: "rwb-section-title" }, t("capability")),
              React.createElement("p", { className: "rwb-hint" }, t("capabilityHint"))
            )
          ),
          React.createElement("div", { className: "rwb-modes" },
            [["inherit", t("inherit")], ["enabled", t("enabled")], ["disabled", t("disabled")]].map(function (entry) {
              return React.createElement("button", { key: entry[0], className: "rwb-chip", "data-active": draft.mode === entry[0], disabled: disabled, onClick: function () { patchDraft({ mode: entry[0] }); } }, entry[1]);
            })
          ),
          draft.mode === "enabled" ? React.createElement(React.Fragment, null,
            React.createElement("div", { className: "rwb-grid" },
              React.createElement("label", { className: "rwb-field" },
                React.createElement("span", { className: "rwb-label" }, t("format")),
                React.createElement("select", { className: "rwb-select", value: draft.format, disabled: disabled, onChange: function (event) { patchDraft({ format: event.target.value }); } },
                  React.createElement("option", { value: "" }, t("formatAuto")),
                  FORMATS.map(function (value) { return React.createElement("option", { key: value, value: value }, value); })
                )
              ),
              React.createElement("label", { className: "rwb-field" },
                React.createElement("span", { className: "rwb-label" }, t("defaultEffort")),
                React.createElement("select", { className: "rwb-select", value: draft.defaultEffort, disabled: disabled, onChange: function (event) { patchDraft({ defaultEffort: event.target.value }); } },
                  React.createElement("option", { value: "" }, t("providerDefault")),
                  enabledLevels.map(function (level) { return React.createElement("option", { key: level, value: level }, level); })
                )
              ),
              React.createElement("label", { className: "rwb-field" },
                React.createElement("span", { className: "rwb-label" }, t("effortField")),
                React.createElement("select", { className: "rwb-select", value: draft.effortField === null ? "" : String(draft.effortField), disabled: disabled, onChange: function (event) { patchDraft({ effortField: event.target.value === "" ? null : event.target.value === "true" }); } },
                  React.createElement("option", { value: "" }, t("inheritAuto")), React.createElement("option", { value: "true" }, t("yes")), React.createElement("option", { value: "false" }, t("no"))
                )
              ),
              React.createElement("label", { className: "rwb-field" },
                React.createElement("span", { className: "rwb-label" }, t("developerRole")),
                React.createElement("select", { className: "rwb-select", value: draft.developerRole === null ? "" : String(draft.developerRole), disabled: disabled, onChange: function (event) { patchDraft({ developerRole: event.target.value === "" ? null : event.target.value === "true" }); } },
                  React.createElement("option", { value: "" }, t("inheritAuto")), React.createElement("option", { value: "true" }, t("yes")), React.createElement("option", { value: "false" }, t("no"))
                )
              )
            ),
            React.createElement("div", { className: "rwb-section-head" },
              React.createElement("div", null, React.createElement("div", { className: "rwb-section-title" }, t("efforts")), React.createElement("p", { className: "rwb-hint" }, t("effortsHint")))
            ),
            React.createElement("div", { className: "rwb-efforts" }, LEVELS.map(function (level) {
              var checked = Object.prototype.hasOwnProperty.call(draft.efforts, level);
              var value = checked && draft.efforts[level] !== null ? draft.efforts[level] : "";
              return React.createElement("label", { className: "rwb-effort", key: level },
                React.createElement("input", { type: "checkbox", checked: checked, disabled: disabled, onChange: function (event) { toggleLevel(level, event.target.checked); } }),
                React.createElement("span", { className: "rwb-effort-name" }, level),
                React.createElement("input", { className: "rwb-input", value: value, disabled: disabled || !checked, placeholder: level === "off" ? t("offPlaceholder") : level, onChange: function (event) { setWire(level, event.target.value); } })
              );
            })),
            draft.defaultEffort ? React.createElement("div", { className: "rwb-warning" }, t("defaultWarning")) : null
          ) : React.createElement("p", { className: "rwb-hint" }, draft.mode === "disabled" ? t("disabledHint") : t("inheritHint")),
          !state.writable ? React.createElement("p", { className: "rwb-status", "data-error": true }, t("readOnly")) : null,
          notice ? React.createElement("p", { className: "rwb-status", "data-ok": notice.ok || undefined, "data-error": !notice.ok || undefined }, notice.text) : null,
          React.createElement("div", { className: "rwb-actions" },
            React.createElement("button", { className: "rwb-button", "data-primary": true, disabled: disabled || !provider || !model, onClick: function () { void save(); } }, busy ? t("saving") : t("save")),
            React.createElement("button", { className: "rwb-button", disabled: disabled || !state.namespace || !provider || !model, onClick: function () { setDraft(currentDraft(state.namespace, provider, model)); setNotice(null); } }, t("discard")),
            React.createElement("button", { className: "rwb-button", disabled: busy, onClick: function () { void load(); } }, t("refresh"))
          )
        )
      );
    }

    var NS = "dshWReasoningBridge";
    var inject = ["slots", "locale", "remote"];
    var dicts = {
      zh: {
        nav: "推理兼容", title: "推理兼容桥", intro: "为中转站和自定义模型声明 DSH 原本无法识别的推理开关、强度与传输协议。",
        provider: "提供方", model: "模型 ID", preset: "协议预设", capability: "模型能力声明", capabilityHint: "这是每模型设置；保存后由 DSH 原生模型选择器显示强度。",
        inherit: "恢复平台定义", enabled: "支持推理", disabled: "标记为不支持", inheritHint: "删除本插件管理的声明，恢复 Pi-AI 内置目录或平台默认行为。",
        disabledHint: "DSH 将不再为此模型显示推理强度。注意：这不能关闭一个无视参数、始终强制思考的上游。",
        format: "推理传输协议", formatAuto: "自动 / 不指定", defaultEffort: "提供方默认强度", providerDefault: "跟随上游默认", effortField: "发送 reasoning_effort", developerRole: "允许 developer 角色", inheritAuto: "自动 / 继承", yes: "是", no: "否",
        efforts: "可选强度与上游值", effortsHint: "左侧决定 DSH 显示哪些强度；右侧是中转站实际收到的值。", offPlaceholder: "留空表示协议自己的关闭方式", defaultWarning: "默认强度属于整个提供方；同一提供方模型能力不同时，建议跟随上游默认并在对话中选择。",
        save: "保存并应用", saving: "正在保存…", discard: "放弃修改", refresh: "刷新", loading: "正在读取模型与设置…", retry: "重试", readOnly: "当前设置存储是只读的，无法保存。", noProviders: "没有可配置的 Pi-AI 提供方。请先在“模型”页面添加中转站。",
      },
      en: {
        nav: "Reasoning compatibility", title: "Reasoning compatibility bridge", intro: "Declare reasoning switches, efforts, and wire dialects for gateways and custom models that DSH cannot infer.",
        provider: "Provider", model: "Model ID", preset: "Protocol preset", capability: "Model capability", capabilityHint: "Per-model configuration; DSH's native model selector exposes the saved efforts.",
        inherit: "Restore platform", enabled: "Reasoning capable", disabled: "Mark unsupported", inheritHint: "Remove bridge-managed declarations and restore the Pi-AI catalog or platform defaults.",
        disabledHint: "DSH will hide reasoning efforts for this model. This cannot disable an upstream that ignores parameters and always reasons.",
        format: "Reasoning wire format", formatAuto: "Auto / unspecified", defaultEffort: "Provider default effort", providerDefault: "Use upstream default", effortField: "Send reasoning_effort", developerRole: "Allow developer role", inheritAuto: "Auto / inherit", yes: "Yes", no: "No",
        efforts: "Selectable efforts and wire values", effortsHint: "The checkbox exposes an effort in DSH; the field is the value sent upstream.", offPlaceholder: "Blank uses the dialect's off form", defaultWarning: "The default is provider-wide. For mixed model capabilities, keep the upstream default and select per conversation.",
        save: "Save and apply", saving: "Saving…", discard: "Discard changes", refresh: "Refresh", loading: "Loading models and settings…", retry: "Retry", readOnly: "The settings provider is read-only.", noProviders: "No configurable Pi-AI provider. Add a gateway on the Models page first.",
      },
    };

    async function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style) style.remove(); }; }, "dsh-w-reasoning-bridge: styles");
      ctx.effect(function () { return ctx.locale.register(NS, dicts); });
      var t = ctx.locale.bind(NS);
      function unwrap(result, label) {
        if (!result.ok) throw new Error(label + ": " + (result.error && result.error.message ? result.error.message : JSON.stringify(result.error)));
        return result.value;
      }
      function injected() {
        return {
          describeSettings: async function () { return unwrap(await ctx.remote.settings.describe(), "settings.describe"); },
          listConfigurableProviders: async function () { return unwrap(await ctx.remote.llm.listConfigurableProviders(), "llm.listConfigurableProviders"); },
          modelCatalog: async function () { return unwrap(await ctx.remote.session.modelCatalog(), "session.modelCatalog"); },
          mutateSettings: function (ns, ops, revision) { return ctx.remote.settings.mutate(ns, ops, revision); },
        };
      }
      ctx.slots.inject("settings.section", function () {
        return ctx.slots.register({
          name: "settings.section", id: "reasoning-bridge", order: 23,
          label: function () { return t("nav"); }, locale: NS, inject: injected,
        }, BridgeSection);
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.name = "dsh-w-reasoning-bridge";
    return module.exports;
  },
});
