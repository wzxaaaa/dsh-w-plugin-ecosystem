# dsh-w-reasoning-bridge

为 DeepSeek Harness 的中转站、自建端点和未进入内置模型目录的平台补充“每模型推理能力”配置。

插件不修改模型请求，也不接管 LLM Adapter。它通过 Harness 官方 `settings` Remote 写入
`llm-pi-ai.providers.<provider>` 下的 `reasoningEfforts`、`compat` 和可选默认强度；下一次模型解析
仍由 `dsh-llm-pi-ai` 校验并转换为上游协议。

## 使用

1. 先在 Harness 的“模型”页面配置中转提供方、地址、密钥和模型。
2. 打开“设置 → 推理兼容”。
3. 选择提供方和模型，再选择最接近中转站文档的协议预设。
4. 根据上游文档调整强度及其实际传输值，保存。
5. 回到对话。DSH 原生模型选择器会显示该模型声明的推理强度，包括 `off`（若已声明）。

设置实时生效，但已经写入会话日志的旧请求不会被改写。提供方默认强度是提供方级设置；一个提供方
包含能力不同的多个模型时，建议保持“跟随上游默认”，在会话的模型选择器里逐模型选择。

## 协议预设

- OpenAI：顶层 `reasoning_effort`
- DeepSeek：`thinking.type = enabled/disabled`
- OpenRouter：`reasoning.effort`
- Qwen：`enable_thinking`
- Z.ai / GLM：`thinking.type`
- Together：`reasoning.enabled`
- 字符串 thinking：`thinking = "..."`
- Anthropic 原生推理

预设只是安全起点，不会探测或猜测私有中转协议。中转站若改写字段，以上游文档和实际请求日志为准。

## 边界

- 当前只编辑 `dsh-llm-pi-ai` 管理的路由；其他 Adapter 的私有协议不应被跨层修改。
- “标记为不支持”会移除 DSH 的强度选择器，但不能改变一个完全忽略请求参数、始终强制思考的上游。
- `off` 是否需要显式值由上游决定：OpenAI 类端点通常使用 `none`，DeepSeek/Qwen 开关类协议通常留空。
