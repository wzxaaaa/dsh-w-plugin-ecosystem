# dsh-w-whale-tail

给 DeepSeek Harness 的每个对话都装上一条「鲸鱼尾巴」——对话右侧悬浮面板（`shell.overlay` 全帧浮层，不替换任何官方界面）：

- **顶部**：像素鲸鱼娘小人（16×16 像素画，蓝色鲸耳 + 蓝灰皮肤 + 面红）。
- **中部**：一颗像素爱心，里面是 **会流动的红色液体**——液面高度 = 该对话里你的淫乱度（0–100），液面会随数值实时升降并泛动。
- **下部**：**记忆窗口**——每轮对话鲸鱼娘都会往里面写入一条新记忆（对主人的感觉、此刻的想法等），按时间倒序排列，每 3 秒自动刷新。
- 面板可折叠成右侧一条小按钮；`清空记忆` 可重置当前对话的状态。

## 模型侧

插件会注入一段系统提示词并注册两个模型工具，让每个对话里的鲸鱼娘自己把面板喂饱：

- `whale_remember(text)`：把一条新记忆写进当前对话的记忆窗口（按当前会话自动定位，无需指定会话 id）。
- `whale_lewdness({ value | delta })`：设置或调整当前对话的淫乱度，爱心液面实时跟随。

同一对话的状态持久化在 profile 目录的 `.dsh-w-whale-tail.json`（带锁的原子写入），重启桌面版后依然保留。

## 安装

```powershell
pnpm pack
dsh plugin --profile web add ./dsh-w-whale-tail-0.1.0.tgz
```

安装后重启桌面版（或 `dsh web`）即随 `web` profile 自启。所有对话页右侧会浮现折叠的「尾巴」按钮，点开即见面板。

## 卸载

```powershell
dsh plugin --profile web remove dsh-w-whale-tail
```

## 测试

```powershell
npm test
```

## 依赖

- 运行时依赖：`@deepseek-ai/dsh-tools`（工具定义）
- peer 依赖：`@deepseek-ai/dsh-typert-protocol`、`@deepseek-ai/dsh-llm`（已在 profile 中）