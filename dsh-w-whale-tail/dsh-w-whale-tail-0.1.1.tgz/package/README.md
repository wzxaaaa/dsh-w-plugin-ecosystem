# dsh-w-whale-tail

给 DeepSeek Harness 的每个对话都装上一条「鲸鱼尾巴」——对话右侧悬浮面板（`shell.overlay` 全帧浮层，不替换任何官方界面）：

- **顶部**：像素鲸鱼娘小人（16×16 像素画，蓝色鲸耳 + 蓝灰皮肤 + 面红）。
- **中部**：一颗像素爱心，里面是 **会流动的红色液体**——液面高度 = 该对话里你的淫乱度（0–100），液面会随数值实时升降并泛动。
- **下部**：**记忆窗口**——每轮对话鲸鱼娘都会往里面写入一条新记忆（对主人的感觉、此刻的想法等），按时间倒序排列，每 3 秒自动刷新。
- 面板可折叠成右侧一条小按钮；`清空记忆` 可重置当前对话的状态。

## 模型侧

插件会注入一段系统提示词并注册两个模型工具，让每个对话里的鲸鱼娘自己把面板喂饱：

- `whale_remember(text)`：把一条新记忆写进当前对话的记忆窗口（按当前会话自动定位，无需指定会话 id）。
- `whale_lewdness({ value | delta })`：设置或调整当前对话的淫乱度，爱心液面实时跟随。

同一对话的状态持久化在 profile 目录的 `.dsh-w-whale-tail.json`（带锁的原子写入），重启桌面版后依然保留。

## 安装

```powershell
pnpm pack
dsh plugin --profile web add ./dsh-w-whale-tail-0.1.1.tgz
```

安装后重启桌面版（或 `dsh web`）即随 `web` profile 自启。所有对话页右侧会浮现折叠的「尾巴」按钮，点开即见面板。

## 卸载

```powershell
dsh plugin --profile web remove dsh-w-whale-tail
```

## 测试

```powershell
npm test
```

## 依赖

- peer 依赖：`@deepseek-ai/dsh-tools`、`@deepseek-ai/dsh-typert-protocol`（由 Harness profile 提供）。
- 插件不直接导入 `@deepseek-ai/dsh-llm`；不要把它当作本插件的额外安装依赖。

## 0.1.1 修复

- 修正 system-prompt section 的 Cordis effect 注册方式。
- 为两个模型工具补齐 Harness 要求的结构化 output schema 与模型可见结果。
- `whale_lewdness` 严格要求 `value` / `delta` 二选一，拒绝空参数或同时传入。
- 修正跨会话轮询竞态、失败时清空旧面板状态、心形 SVG ID 冲突和心形液面过渡被禁用的问题。
- 接入中英文界面字典，并在插件卸载时清理自有样式。
