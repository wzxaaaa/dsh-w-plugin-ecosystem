window.__ModuleLoader__.load({
  id: "dsh-w-whale-tail",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");

    // ── pixel-art data & palette (mirrors whale-tail-core.js — the bundle is
    // standalone and cannot import host ESM) ─────────────────────────────
    var P = ".";
    var PALETTE = {
      H: "#2b3a67",
      S: "#a9c0e0",
      s: "#8aa9d1",
      E: "#5d84bd",
      e: "#dbe7f7",
      B: "#1c2744",
      W: "#ffffff",
      C: "#f3a6a6",
      M: "#7a4a5e",
      T: "#ec93a5",
    };
    var AVATAR_ROWS = [
      "................",
      "..EE........EE..",
      ".EEEE......EEEE.",
      ".EHHHHHHHHHHHHE.",
      "..HHHHHHHHHHHH..",
      "..HHSSSSSSSSHH..",
      "..HSSSSSSSSSSH..",
      "..HSSBBBBBBSSH..",
      "..HSSBWWWWBSSH..",
      "..HSSBBBBBBSSH..",
      "..HSSSSSSSSSSH..",
      "..HSSSCCCCSSSH..",
      "..HSSSCCCCSSSH..",
      "..HSSSSMMSSSSH..",
      "..HHHHHHHHHHHH..",
      "................",
    ];
    var HEART_PATH = "M12 21C6 16 1 11 1 6C1 2 4 0 7 0C9 0 11 1 12 3C13 1 15 0 17 0C20 0 23 2 23 6C23 11 18 16 12 21Z";

    // ── stylesheet ───────────────────────────────────────────────────────
    var CSS = [
      ".dshww-page{display:flex;flex:1;min-height:0;flex-direction:column;gap:10px;padding:12px;background:var(--dsw-alias-bg-layer-1,#fff);overflow:hidden}",
      ".dshww-rail-button{width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:0;background:transparent;color:var(--dsw-alias-label-secondary,#68717e);cursor:pointer}",
      ".dshww-rail-button:hover{background:var(--dsw-alias-interactive-bg-hover,#e9edf3);color:var(--dsw-alias-label-primary,#1f2329)}",
      ".dshww-feature-icon{width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:20px;line-height:1}",
      ".dshww-avatar{display:flex;justify-content:center;padding:4px 0 2px;image-rendering:pixelated;filter:drop-shadow(0 2px 6px rgba(90,132,189,.45))}",
      ".dshww-heartwrap{display:flex;flex-direction:column;align-items:center;gap:2px;padding:4px 0 2px}",
      ".dshww-heart{position:relative;width:104px;height:96px;overflow:hidden;filter:drop-shadow(0 0 10px rgba(236,72,90,.45))}",
      ".dshww-heart svg{display:block;width:100%;height:100%}",
      ".dshww-heart-fill{transition:y .5s cubic-bezier(.4,0,.2,1),height .5s cubic-bezier(.4,0,.2,1)}",
      ".dshww-heart-wave{animation:dshww-wave 2.6s linear infinite}",
      "@keyframes dshww-wave{0%{transform:translateX(0)}100%{transform:translateX(-28px)}}",
      ".dshww-heart-glow{animation:dshww-pulse 1.6s ease-in-out infinite}",
      "@keyframes dshww-pulse{0%,100%{filter:drop-shadow(0 0 6px rgba(236,72,90,.25))}50%{filter:drop-shadow(0 0 16px rgba(236,72,90,.75))}}",
      ".dshww-level{font-size:12px;font-weight:700;color:var(--dsw-alias-label-primary,#f3f5f8);letter-spacing:1px}",
      ".dshww-level small{font-size:10px;font-weight:500;color:var(--dsw-alias-label-tertiary,#9aa4b2)}",
      ".dshww-label{font-size:10px;font-weight:600;color:var(--dsw-alias-label-tertiary,#9aa4b2);letter-spacing:3px;text-align:center;border-bottom:1px solid var(--dsw-alias-border-l2,#333c4e);padding-bottom:6px;flex:none}",
      ".dshww-memories{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:8px;padding:2px 2px 6px;scrollbar-width:thin}",
      ".dshww-memory{display:flex;flex-direction:column;gap:2px;border-left:2px solid color-mix(in srgb,var(--dsw-alias-state-business-primary,#4f8cff) 55%,transparent);padding-left:8px;animation:dshww-in .25s ease both}",
      ".dshww-memory-time{font-size:10px;color:var(--dsw-alias-label-tertiary,#9aa4b2)}",
      ".dshww-memory-text{font-size:12px;line-height:17px;color:var(--dsw-alias-label-primary,#f3f5f8);word-break:break-word}",
      "@keyframes dshww-in{from{opacity:0;transform:translateX(6px)}to{opacity:1;transform:none}}",
      ".dshww-empty{font-size:11px;color:var(--dsw-alias-label-tertiary,#9aa4b2);text-align:center;padding:10px 4px;line-height:17px}",
      ".dshww-reset{flex:none;align-self:flex-end;font-size:10px;color:var(--dsw-alias-label-tertiary,#9aa4b2);background:transparent;border:1px solid var(--dsw-alias-border-l2,#333c4e);border-radius:6px;padding:3px 8px;cursor:pointer;pointer-events:auto}",
      ".dshww-reset:hover{color:var(--dsw-alias-state-danger-primary,#ff6b6b);border-color:color-mix(in srgb,var(--dsw-alias-state-danger-primary,#ff6b6b) 55%,transparent)}",
      ".dshww-status{font-size:10px;line-height:14px;color:var(--dsw-alias-label-tertiary,#9aa4b2);padding:0 2px}",
      ".dshww-status-error{color:var(--dsw-alias-state-danger-primary,#ff6b6b)}",
      "@media (max-width:720px){.dshww-page{padding:10px}}",
    ].join("\n");
    var tagId = "dsh-w-whale-tail/styles";
    function installStyle() {
      if (typeof document === "undefined") return { owned: false, node: null };
      var existing = document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]");
      if (existing) return { owned: false, node: existing };
      var styleTag = document.createElement("style");
      styleTag.dataset.plugin = "dsh-w-whale-tail";
      styleTag.dataset.pluginCss = tagId;
      styleTag.textContent = CSS;
      document.head.appendChild(styleTag);
      return { owned: true, node: styleTag };
    }

    // ── Remote contribution (client face of the Host `whaleTail` service) ──
    var passthrough = { parse: function (v) { return v; } };
    function parameter(name) {
      return { name: name, wire: name, source: "json", codec: { mode: "strict", typeSymbol: "json", schema: passthrough } };
    }
    function descriptor(method, parameters) {
      return {
        id: "dsh-w-whale-tail#whaleTail/" + method,
        service: "whaleTail",
        namespace: "whaleTail",
        method: method,
        invocation: { kind: "direct" },
        parameters: parameters || [],
        result: { mode: "strict", typeSymbol: "json", schema: passthrough },
      };
    }
    var TYPERT_REMOTE = {
      package: "dsh-w-whale-tail",
      descriptors: [
        descriptor("getState", [parameter("sessionId")]),
        descriptor("appendMemory", [parameter("sessionId"), parameter("text")]),
        descriptor("setLewdness", [parameter("sessionId"), parameter("value")]),
        descriptor("reset", [parameter("sessionId")]),
      ],
    };

    // ── pixel avatar: render the 16x16 grid as SVG rects ─────────────────
    function PixelAvatar() {
      var cell = 5;
      var rects = [];
      for (var row = 0; row < AVATAR_ROWS.length; row++) {
        var line = AVATAR_ROWS[row];
        for (var col = 0; col < line.length; col++) {
          var ch = line[col];
          if (ch === P) continue;
          var fill = PALETTE[ch];
          if (fill === undefined) continue;
          rects.push(React.createElement("rect", {
            key: row + "-" + col,
            x: col * cell,
            y: row * cell,
            width: cell,
            height: cell,
            fill: fill,
          }));
        }
      }
      var size = 16 * cell;
      return React.createElement(
        "svg",
        { className: "dshww-avatar-svg", width: size, height: size, viewBox: "0 0 " + size + " " + size, shapeRendering: "crispEdges", "aria-hidden": true, style: { width: 84, height: 84 } },
        rects
      );
    }

    // ── pixel heart with flowing red liquid ──────────────────────────────
    var heartInstance = 0;
    function PixelHeart(props) {
      var level = props.level;
      var fillPct = Math.max(0, Math.min(100, Math.round(level)));
      var liquidTop = 24 - (fillPct / 100) * 24;
      var idRef = React.useRef(null);
      if (idRef.current === null) idRef.current = "dshww-" + (++heartInstance);
      var gradientId = idRef.current + "-blood";
      var clipId = idRef.current + "-clip";
      // Wave rides the liquid surface inside the heart clip.
      var wave = React.createElement("rect", {
        className: "dshww-heart-wave",
        x: -28,
        y: liquidTop - 2.2,
        width: 80,
        height: 3,
        fill: "#ff5c74",
        opacity: 0.9,
      });
      return React.createElement(
        "div",
        { className: "dshww-heart" + (fillPct >= 80 ? " dshww-heart-glow" : ""), title: "淫乱度 " + fillPct + " / 100" },
        React.createElement(
          "svg",
          { viewBox: "0 0 24 24" },
          React.createElement("defs", null,
            React.createElement("linearGradient", { id: gradientId, x1: "0", y1: "0", x2: "0", y2: "1" },
              React.createElement("stop", { offset: "0%", stopColor: "#ff6b81" }),
              React.createElement("stop", { offset: "100%", stopColor: "#d9203c" })
            )
          ),
          React.createElement("clipPath", { id: clipId }, React.createElement("path", { d: HEART_PATH })),
          React.createElement(
            "g", { clipPath: "url(#" + clipId + ")" },
            React.createElement("rect", { x: 0, width: 24, className: "dshww-heart-fill", y: liquidTop, height: 24 - liquidTop + 2, fill: "url(#" + gradientId + ")" }),
            wave
          ),
          React.createElement("path", {
            d: HEART_PATH,
            fill: "none",
            stroke: "#ff5c74",
            strokeWidth: 1.4,
            strokeLinejoin: "miter",
            vectorEffect: "non-scaling-stroke",
          })
        )
      );
    }

    function formatTime(at) {
      if (!Number.isFinite(at)) return "";
      var diff = Math.max(0, Date.now() - at);
      var minute = 60000, hour = 3600000, day = 86400000;
      if (diff < minute) return "刚刚";
      if (diff < hour) return Math.floor(diff / minute) + " 分钟前";
      if (diff < day) return Math.floor(diff / hour) + " 小时前";
      var d = Math.floor(diff / day);
      if (d < 7) return d + " 天前";
      var date = new Date(at);
      var pad = function (n) { return String(n).padStart(2, "0"); };
      return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) + " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
    }

    // ── the panel ────────────────────────────────────────────────────────
    function WhaleTailPage(props) {
      var t = typeof props.t === "function" ? props.t : function (key) { return key; };
      var useSessions = props.useSessions;
      var whale = props.whale;
      // `useSessions` is a selector hook, not a zero-argument snapshot getter.
      // Passing an identity selector is required in the real shell renderer;
      // calling it without one crashes this overlay before it can paint.
      var sessionList = useSessions(function (state) { return state; });
      var sessionId = sessionList && sessionList.current != null ? String(sessionList.current) : null;

      var stateSlot = React.useState({ status: "idle", lewdness: 0, memories: [] });
      var state = stateSlot[0];
      var setState = stateSlot[1];
      var mountedRef = React.useRef(true);
      var pollTimerRef = React.useRef(null);
      var requestRef = React.useRef(0);
      var resetSlot = React.useState(false);
      var resetting = resetSlot[0];
      var setResetting = resetSlot[1];

      var load = React.useCallback(function (sid, silent) {
        var requestId = ++requestRef.current;
        if (sid == null) {
          setState({ status: "idle", lewdness: 0, memories: [] });
          return;
        }
        if (!silent) setState(function (current) { return { status: "loading", lewdness: current.lewdness, memories: current.memories }; });
        whale.getState(sid).then(
          function (view) {
            if (!mountedRef.current || requestId !== requestRef.current || sid !== sessionId) return;
            setState({
              status: "ready",
              lewdness: Number.isFinite(view.lewdness) ? view.lewdness : 0,
              memories: Array.isArray(view.memories) ? view.memories : [],
            });
          },
          function (err) {
            if (!mountedRef.current || requestId !== requestRef.current || sid !== sessionId) return;
            console.error("dsh-w-whale-tail: getState failed:", err);
            setState(function (current) {
              return { status: "error", lewdness: current.lewdness, memories: current.memories };
            });
          }
        );
      }, [sessionId, whale]);

      React.useEffect(function () {
        mountedRef.current = true;
        return function () {
          mountedRef.current = false;
          if (pollTimerRef.current !== null) {
            window.clearInterval(pollTimerRef.current);
            pollTimerRef.current = null;
          }
        };
      }, []);

      // Reload on conversation switch, and poll every 3s so new memories the
      // whale girl writes appear live.
      React.useEffect(function () {
        load(sessionId, false);
        if (pollTimerRef.current !== null) {
          window.clearInterval(pollTimerRef.current);
          pollTimerRef.current = null;
        }
        if (sessionId == null) return;
        pollTimerRef.current = window.setInterval(function () {
          load(sessionId, true);
        }, 3000);
      }, [sessionId, load]);

      function onReset() {
        if (sessionId == null || resetting) return;
        setResetting(true);
        whale.reset(sessionId).then(function () {
          load(sessionId, false);
        }, function (err) {
          console.error("dsh-w-whale-tail: reset failed:", err);
          setState(function (current) { return { status: "error", lewdness: current.lewdness, memories: current.memories }; });
        }).finally(function () {
          if (mountedRef.current) setResetting(false);
        });
      }

      if (sessionId == null) {
        return React.createElement("div", { className: "dshww-page" },
          React.createElement("div", { className: "dshww-empty" }, t("noSession"))
        );
      }

      return React.createElement(
        "div", { className: "dshww-page" },
          React.createElement("div", { className: "dshww-avatar" }, React.createElement(PixelAvatar, null)),
          React.createElement(
            "div", { className: "dshww-heartwrap" },
            React.createElement(PixelHeart, { level: state.lewdness }),
            React.createElement("div", { className: "dshww-level" }, String(state.lewdness), React.createElement("small", null, " / 100"))
          ),
          React.createElement("div", { className: "dshww-label" }, t("memoryLabel")),
          React.createElement(
            "div", { className: "dshww-memories" },
            state.status === "loading" ? React.createElement("div", { className: "dshww-empty" }, t("loading")) : null,
            state.status === "error" ? React.createElement("div", { className: "dshww-empty dshww-status-error" }, t("error")) : null,
            state.status === "ready" && state.memories.length === 0
              ? React.createElement("div", { className: "dshww-empty" }, t("empty"))
              : null,
            state.status === "ready" && state.memories.length > 0
              ? state.memories.map(function (m) {
                  return React.createElement(
                    "div", { className: "dshww-memory", key: m.id || m.at },
                    React.createElement("span", { className: "dshww-memory-time" }, m.timeLabel || formatTime(m.at)),
                    React.createElement("span", { className: "dshww-memory-text" }, m.text)
                  );
                })
              : null
          ),
          state.status === "error" ? React.createElement("div", { className: "dshww-status dshww-status-error" }, t("error")) : null,
          React.createElement("button", { type: "button", className: "dshww-reset", onClick: onReset, disabled: resetting, "aria-label": t("reset") }, resetting ? t("resetting") : t("reset"))
      );
    }

    function WhaleTailRail(props) {
      var t = typeof props.t === "function" ? props.t : function (key) { return key; };
      var active = props.activeId === "whale-tail";
      return React.createElement("div", { className: "dshww-feature-icon" },
        React.createElement("button", {
          type: "button",
          className: "dshww-rail-button",
          "data-active": active || undefined,
          title: t("tab"),
          "aria-label": t("tab"),
          onClick: function () { props.onSelect("whale-tail"); },
        }, "🐋")
      );
    }

    // ── plugin ───────────────────────────────────────────────────────────
    var NS = "dshWWhaleTail";
    var inject = ["slots", "locale", "remote"];

    var dicts = {
      zh: {
        tab: "\u9cb8\u9c7c\u5c3e\u5df4",
        loading: "\u6b63\u5728\u8bfb\u53d6\u8bb0\u5fc6...",
        error: "\u8bfb\u53d6\u5931\u8d25\u3002",
        empty: "\u4f60\u8fd8\u6ca1\u6709\u5199\u4e0b\u7b2c\u4e00\u6761\u8bb0\u5fc6\u3002\n\u8bd5\u7740\u5bf9\u6211\u8bf4\u70b9\u4ec0\u4e48\u5427\u3002",
        memoryLabel: "\u8bb0\u5fc6 \u00b7 MEMORY",
        open: "\u6253\u5f00\u9cb8\u9c7c\u5c3e\u5df4\u9762\u677f",
        noSession: "\u6ca1\u6709\u6b63\u5728\u8fdb\u884c\u7684\u5bf9\u8bdd",
        resetting: "\u6e05\u7406\u4e2d\u2026",
        reset: "\u6e05\u7a7a\u8bb0\u5fc6",
      },
      en: {
        tab: "Whale tail",
        loading: "Reading memories...",
        error: "Failed to read memories.",
        empty: "No memories yet.",
        memoryLabel: "Memory · MEMORY",
        open: "Open whale-tail panel",
        noSession: "No conversation is active",
        resetting: "Clearing...",
        reset: "Clear memories",
      },
    };

    async function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style.owned && style.node) style.node.remove(); }; }, "dsh-w-whale-tail: styles");
      ctx.effect(function () { return ctx.locale.register(NS, dicts); });
      var t = ctx.locale.bind(NS);

      var unmount = await ctx.remote.$mount(TYPERT_REMOTE);
      ctx.effect(function () { return unmount; }, "dsh-w-whale-tail: remote");

      var whaleTail = ctx.get("remote.whaleTail");
      if (!whaleTail) throw new Error("dsh-w-whale-tail: remote.whaleTail did not mount");

      function unwrap(method, args) {
        return whaleTail[method].apply(whaleTail, args).then(function (result) {
          if (!result.ok) throw new Error("whaleTail." + method + " failed: " + JSON.stringify(result.error));
          return result.value;
        });
      }

      function injected() {
        return {
          whale: {
            getState: function (sessionId) { return unwrap("getState", [sessionId]); },
            appendMemory: function (sessionId, text) { return unwrap("appendMemory", [sessionId, text]); },
            setLewdness: function (sessionId, value) { return unwrap("setLewdness", [sessionId, value]); },
            reset: function (sessionId) { return unwrap("reset", [sessionId]); },
          },
        };
      }

      ctx.slots.inject("right-sidebar.rail", function () {
        return ctx.slots.register({
          name: "right-sidebar.rail",
          id: "whale-tail",
          order: 100,
          label: function () { return t("tab"); },
          locale: NS,
          inject: injected,
        }, WhaleTailRail);
      });
      ctx.slots.inject("right-sidebar.page", function () {
        return ctx.slots.register({
          name: "right-sidebar.page",
          priority: 100,
          select: function (owner) {
            return owner && owner.activeId === "whale-tail" ? {} : null;
          },
          locale: NS,
          inject: injected,
        }, WhaleTailPage);
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.name = "dsh-w-whale-tail";
    return module.exports;
  },
});
