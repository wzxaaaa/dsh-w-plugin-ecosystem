window.__ModuleLoader__.load({
  id: "dsh-w-assistant-refresh",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    var React = require("react");
    var primitives = require("@deepseek-ai/dsh-client-ui-primitives");
    var IconRefreshOutline16 = primitives.IconRefreshOutline16;
    var Tooltip = primitives.Tooltip;

    var NS = "assistantRefresh";
    var TRIGGER_SUMMARY = "dsh-w-assistant-refresh/internal-regenerate";
    var CSS = [
      ".dshwar-slot{display:inline-flex;align-items:center;order:1;gap:6px}",
      "[data-slot=\"conversation.chat.assistant-actions\"]~span{order:2}",
      "[data-chat-flow-kind=context]:has([data-context-summary=\"" + TRIGGER_SUMMARY + "\"]){display:none!important}",
      ".dshwar-action{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;padding:6px;border:0;border-radius:28px;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer}",
      ".dshwar-action:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}",
      ".dshwar-action[data-unavailable]{cursor:default;opacity:.4}",
      ".dshwar-action[data-unavailable]:hover{background:transparent;color:var(--dsw-alias-label-tertiary)}",
      ".dshwar-error{max-width:220px;overflow:hidden;color:var(--dsw-alias-state-danger-primary,#c33);font-size:12px;line-height:20px;text-overflow:ellipsis;white-space:nowrap}",
      ".dshwar-live{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}",
    ].join("\n");

    var zh = {
      refresh: "刷新回复",
      refreshing: "正在刷新回复…",
      running: "请等待当前请求完成",
      failed: "刷新失败",
    };
    var en = {
      refresh: "Refresh reply",
      refreshing: "Refreshing reply…",
      running: "Wait for the current request to finish",
      failed: "Refresh failed",
    };

    function installStyle() {
      var selector = 'style[data-plugin-css="dsh-w-assistant-refresh/styles"]';
      var existing = document.querySelector(selector);
      if (existing) {
        existing.textContent = CSS;
        return { node: existing, owned: false };
      }
      var node = document.createElement("style");
      node.dataset.plugin = "dsh-w-assistant-refresh";
      node.dataset.pluginCss = "dsh-w-assistant-refresh/styles";
      node.textContent = CSS;
      document.head.appendChild(node);
      return { node: node, owned: true };
    }

    var passthrough = { parse: function (value) { return value; } };
    function parameter(name) {
      return { name: name, wire: name, source: "json", codec: { mode: "strict", typeSymbol: "json", schema: passthrough } };
    }
    function descriptor(method, parameters) {
      return {
        id: "dsh-w-assistant-refresh#assistantRefresh/" + method,
        service: "assistantRefresh",
        namespace: "assistantRefresh",
        method: method,
        invocation: { kind: "direct" },
        parameters: parameters || [],
        result: { mode: "strict", typeSymbol: "json", schema: passthrough },
      };
    }
    var TYPERT_REMOTE = {
      package: "dsh-w-assistant-refresh",
      descriptors: [descriptor("regenerate", [parameter("sessionId"), parameter("assistantMessageId")])],
    };

    function errorMessage(error) {
      return error instanceof Error ? error.message : String(error);
    }

    function RefreshAction(props) {
      var running = props.useSession(value => value?.running === true);
      var failureState = React.useState(null);
      var failure = failureState[0];
      var setFailure = failureState[1];
      var pendingState = React.useState(false);
      var pending = pendingState[0];
      var setPending = pendingState[1];
      var unavailable = running || pending;
      var onClick = function () {
        if (unavailable) return;
        setFailure(null);
        setPending(true);
        Promise.resolve(props.refresh(props.messageId))
          .catch(error => { setFailure(errorMessage(error)); })
          .finally(() => { setPending(false); });
      };
      var label = pending ? props.t("refreshing") : failure === null ? props.t("refresh") : props.t("failed");
      return React.createElement("span", { className: "dshwar-slot" },
        React.createElement(Tooltip, { label: running ? props.t("running") : label, side: "bottom" },
          React.createElement("button", {
            type: "button",
            className: "dshwar-action",
            "aria-label": label,
            "aria-disabled": unavailable || undefined,
            "data-unavailable": unavailable || undefined,
            onClick: onClick,
          }, React.createElement(IconRefreshOutline16))),
        failure !== null && React.createElement("span", { className: "dshwar-error", role: "status" }, failure),
        failure !== null && React.createElement("span", { className: "dshwar-live", "aria-live": "polite" }, props.t("failed")),
      );
    }

    async function apply(ctx) {
      var style = installStyle();
      ctx.effect(function () { return function () { if (style.owned) style.node.remove(); }; }, "dsh-w-assistant-refresh: styles");
      ctx.effect(() => ctx.locale.register(NS, { zh: zh, en: en }), "dsh-w-assistant-refresh: dictionaries");
      var unmount = await ctx.remote.$mount(TYPERT_REMOTE);
      ctx.effect(function () { return unmount; }, "dsh-w-assistant-refresh: remote");
      var remote = ctx.get("remote.assistantRefresh");
      if (!remote) throw new Error("dsh-w-assistant-refresh: remote.assistantRefresh did not mount");

      async function regenerate(sessionId, messageId) {
        var result = await remote.regenerate(sessionId, messageId);
        if (!result.ok) throw new Error("assistantRefresh.regenerate failed: " + JSON.stringify(result.error));
        return result.value;
      }

      ctx.slots.inject("conversation.chat.assistant-actions", () => ctx.slots.register({
        name: "conversation.chat.assistant-actions",
        id: "assistant-refresh",
        order: 20,
        locale: NS,
        inject: (sessionId) => ({
          refresh: messageId => regenerate(sessionId, messageId),
        }),
      }, RefreshAction));
    }

    exports.apply = apply;
    exports.inject = ["slots", "sessions", "remote", "locale"];
    module.exports = exports;
    return module.exports;
  },
});