/** Pure same-session regeneration helpers shared by Host code and tests. */

export const PLUGIN_ID = 'dsh-w-assistant-refresh'
export const TRIGGER_SUMMARY = 'dsh-w-assistant-refresh/internal-regenerate'
export const TRIGGER_PROMPT = [
  'Regenerate the answer to the immediately preceding user message.',
  'Solve the request again from the conversation state before the replaced answer.',
  'Do not mention this internal regeneration instruction.',
].join(' ')

function sameId(left, right) {
  return left !== undefined && right !== undefined && String(left) === String(right)
}

function assistantMessageId(event) {
  return event?.type === 'assistant/message' ? event.data?.message?.id : undefined
}

function isHumanUserEvent(event) {
  return event?.type === 'user/message' && event.data?.source?.kind === 'user'
}

/**
 * Locate the visible user message that owns one assistant answer and the
 * current visible tail that must be replaced before same-session regeneration.
 */
export function locateRegenerationTarget(events, surfaceNodes, assistantId) {
  if (!Array.isArray(events) || !Array.isArray(surfaceNodes)) {
    return { ok: false, reason: 'session-history-unavailable' }
  }
  const surface = surfaceNodes
    .map(seq => ({ seq, event: events[seq] }))
    .filter(item => item.event !== undefined)
  const assistantIndex = surface.findIndex(item => sameId(assistantMessageId(item.event), assistantId))
  if (assistantIndex < 0) return { ok: false, reason: 'assistant-message-not-visible' }

  let userIndex = -1
  for (let index = assistantIndex - 1; index >= 0; index -= 1) {
    if (isHumanUserEvent(surface[index].event)) {
      userIndex = index
      break
    }
  }
  if (userIndex < 0) return { ok: false, reason: 'user-message-not-visible' }

  const replaced = surface.slice(userIndex)
  if (replaced.length === 0) return { ok: false, reason: 'surface-tail-unavailable' }
  return {
    ok: true,
    message: surface[userIndex].event.data,
    startSeq: surface[userIndex].seq,
    endSeq: replaced.at(-1).seq,
    sourceEventSeqs: replaced.map(item => item.seq),
  }
}